import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ---------------------------------------------------------------------------
// GrabAll config
// ---------------------------------------------------------------------------
const String kApiBase = 'https://ytcreater.pythonanywhere.com';
const String kBannerId = 'ca-app-pub-9808430389913183/7964379134';
const String kInterstitialId = 'ca-app-pub-9808430389913183/4978464001';

const List<Map<String, String>> kPlatforms = [
  {'name': 'Instagram', 'match': 'instagram.com'},
  {'name': 'Facebook', 'match': 'facebook.com'},
  {'name': 'Facebook', 'match': 'fb.watch'},
  {'name': 'TikTok', 'match': 'tiktok.com'},
  {'name': 'YouTube', 'match': 'youtube.com'},
  {'name': 'YouTube', 'match': 'youtu.be'},
  {'name': 'RedNote', 'match': 'xiaohongshu.com'},
  {'name': 'RedNote', 'match': 'xhslink.com'},
  {'name': 'Bilibili', 'match': 'bilibili.com'},
  {'name': 'Bilibili', 'match': 'b23.tv'},
  {'name': 'X (Twitter)', 'match': 'twitter.com'},
  {'name': 'X (Twitter)', 'match': 'x.com'},
  {'name': 'SnackVideo', 'match': 'snackvideo.com'},
  {'name': 'SnackVideo', 'match': 'kwai.com'},
  {'name': 'Likee', 'match': 'likee.video'},
  {'name': 'Snapchat', 'match': 'snapchat.com'},
  {'name': 'Pinterest', 'match': 'pinterest.com'},
  {'name': 'Pinterest', 'match': 'pin.it'},
  {'name': 'Reddit', 'match': 'reddit.com'},
  {'name': 'Vimeo', 'match': 'vimeo.com'},
  {'name': 'Dailymotion', 'match': 'dailymotion.com'},
  {'name': 'Dailymotion', 'match': 'dai.ly'},
  {'name': 'SoundCloud', 'match': 'soundcloud.com'},
  {'name': 'Twitch', 'match': 'twitch.tv'},
  {'name': 'Threads', 'match': 'threads.net'},
  {'name': 'Threads', 'match': 'threads.com'},
];

const List<String> kPlatformNames = [
  'Instagram', 'Facebook', 'TikTok', 'YouTube', 'RedNote', 'Bilibili',
  'X (Twitter)', 'SnackVideo', 'Likee', 'Snapchat', 'Pinterest', 'Reddit',
  'Vimeo', 'Dailymotion', 'SoundCloud', 'Twitch', 'Threads',
];

String? detectPlatform(String url) {
  final u = url.toLowerCase();
  for (final p in kPlatforms) {
    if (u.contains(p['match']!)) return p['name'];
  }
  return null;
}

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
class GrabFormat {
  final String label;
  final String url;
  final String ext;
  final bool isAudio;
  const GrabFormat(this.label, this.url, this.ext, this.isAudio);
}

class GrabResult {
  final String title;
  final String? thumbnail;
  final String? uploader;
  final String platform;
  final List<GrabFormat> formats;
  const GrabResult({
    required this.title,
    this.thumbnail,
    this.uploader,
    required this.platform,
    required this.formats,
  });
}

class DownloadRecord {
  final String title;
  final String platform;
  final String formatLabel;
  final String path;
  final int size;
  final int dateMs;
  const DownloadRecord({
    required this.title,
    required this.platform,
    required this.formatLabel,
    required this.path,
    required this.size,
    required this.dateMs,
  });
  Map<String, dynamic> toJson() => {
        'title': title,
        'platform': platform,
        'formatLabel': formatLabel,
        'path': path,
        'size': size,
        'dateMs': dateMs,
      };
  factory DownloadRecord.fromJson(Map<String, dynamic> j) => DownloadRecord(
        title: j['title'] ?? '',
        platform: j['platform'] ?? '',
        formatLabel: j['formatLabel'] ?? '',
        path: j['path'] ?? '',
        size: j['size'] ?? 0,
        dateMs: j['dateMs'] ?? 0,
      );
}

// ---------------------------------------------------------------------------
// Extraction
// ---------------------------------------------------------------------------
Future<GrabResult> extractLink(String url) async {
  final platform = detectPlatform(url) ?? 'Video';
  if (platform == 'TikTok') {
    return _extractTikTok(url);
  }
  return _extractViaEngine(url, platform);
}

Future<GrabResult> _extractTikTok(String url) async {
  final uri = Uri.parse(
      'https://www.tikwm.com/api/?url=${Uri.encodeComponent(url)}&hd=1');
  final resp = await http.get(uri).timeout(const Duration(seconds: 30));
  final body = jsonDecode(resp.body) as Map<String, dynamic>;
  if (body['code'] != 0 || body['data'] == null) {
    throw Exception('TikTok could not read this link. Check the link and try again.');
  }
  final d = body['data'] as Map<String, dynamic>;
  final formats = <GrabFormat>[];
  if (d['play'] != null) {
    formats.add(GrabFormat('Video — No Watermark', d['play'], 'mp4', false));
  }
  if (d['hdplay'] != null && d['hdplay'] != d['play']) {
    formats.add(GrabFormat('Video — HD', d['hdplay'], 'mp4', false));
  }
  if (d['wmplay'] != null) {
    formats.add(GrabFormat('Video — With Watermark', d['wmplay'], 'mp4', false));
  }
  if (d['music'] != null) {
    formats.add(GrabFormat('MP3 Audio', d['music'], 'mp3', true));
  }
  if (formats.isEmpty) {
    throw Exception('No downloadable formats found for this link.');
  }
  return GrabResult(
    title: (d['title'] ?? 'TikTok Video').toString(),
    thumbnail: d['cover']?.toString(),
    uploader: (d['author'] is Map) ? d['author']['nickname']?.toString() : null,
    platform: 'TikTok',
    formats: formats,
  );
}

Future<GrabResult> _extractViaEngine(String url, String platform) async {
  http.Response resp;
  try {
    resp = await http
        .post(
          Uri.parse('$kApiBase/extract'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'url': url}),
        )
        .timeout(const Duration(seconds: 45));
  } catch (_) {
    throw Exception(
        'The GrabAll engine is still being connected for $platform. TikTok links already work fully — more platforms are coming online very soon.');
  }
  if (resp.statusCode != 200) {
    throw Exception(
        'The engine could not fetch this $platform link yet. Please try another link.');
  }
  final body = jsonDecode(resp.body) as Map<String, dynamic>;
  final formats = <GrabFormat>[];
  final videos = (body['videos'] as List?) ?? [];
  for (final v in videos) {
    final m = v as Map<String, dynamic>;
    formats.add(GrabFormat(
      'Video — ${m['height']}p',
      m['url'].toString(),
      (m['ext'] ?? 'mp4').toString(),
      false,
    ));
  }
  final audio = body['audio'];
  if (audio is Map<String, dynamic> && audio['url'] != null) {
    formats.add(GrabFormat(
        'MP3 Audio', audio['url'].toString(), (audio['ext'] ?? 'm4a').toString(), true));
  }
  if (formats.isEmpty) {
    throw Exception('No downloadable formats found for this link.');
  }
  return GrabResult(
    title: (body['title'] ?? 'Video').toString(),
    thumbnail: body['thumbnail']?.toString(),
    uploader: body['uploader']?.toString(),
    platform: (body['platform'] ?? platform).toString(),
    formats: formats,
  );
}

String sanitize(String s) {
  var out = s.replaceAll(RegExp(r'[\\/:*?"<>|]'), ' ').trim();
  out = out.replaceAll(RegExp(r'\s+'), ' ');
  if (out.length > 60) out = out.substring(0, 60).trim();
  return out.isEmpty ? 'GrabAll' : out;
}

String fmtSize(int bytes) {
  if (bytes <= 0) return '';
  const units = ['B', 'KB', 'MB', 'GB'];
  var i = 0;
  double v = bytes.toDouble();
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return '${v.toStringAsFixed(v >= 100 ? 0 : 1)} ${units[i]}';
}

// ---------------------------------------------------------------------------
// App
// ---------------------------------------------------------------------------
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await MobileAds.instance.initialize();
  runApp(const GrabAllApp());
}

class GrabAllApp extends StatelessWidget {
  const GrabAllApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GrabAll',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7C3AED),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
      ),
      home: const HomeShell(),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;
  BannerAd? _banner;
  bool _bannerLoaded = false;
  InterstitialAd? _interstitial;
  DateTime _lastInterstitial = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    _loadBanner();
    _loadInterstitial();
  }

  void _loadBanner() {
    _banner = BannerAd(
      size: AdSize.banner,
      adUnitId: kBannerId,
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => _bannerLoaded = true),
        onAdFailedToLoad: (ad, _) => ad.dispose(),
      ),
      request: const AdRequest(),
    )..load();
  }

  void _loadInterstitial() {
    InterstitialAd.load(
      adUnitId: kInterstitialId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) => _interstitial = ad,
        onAdFailedToLoad: (_) => _interstitial = null,
      ),
    );
  }

  void _maybeShowInterstitial() {
    final now = DateTime.now();
    if (now.difference(_lastInterstitial).inMinutes < 3) return;
    final ad = _interstitial;
    if (ad == null) return;
    _lastInterstitial = now;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _loadInterstitial();
      },
      onAdFailedToShowFullScreenContent: (ad, _) {
        ad.dispose();
        _loadInterstitial();
      },
    );
    ad.show();
    _interstitial = null;
  }

  @override
  void dispose() {
    _banner?.dispose();
    _interstitial?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      const GrabTab(),
      const DownloadsTab(),
      const MoreTab(),
    ];
    return Scaffold(
      body: IndexedStack(index: _tab, children: pages),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_bannerLoaded && _banner != null)
            SizedBox(
              width: _banner!.size.width.toDouble(),
              height: _banner!.size.height.toDouble(),
              child: AdWidget(ad: _banner!),
            ),
          NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) {
              if (i == 1 && _tab != 1) _maybeShowInterstitial();
              setState(() => _tab = i);
            },
            destinations: const [
              NavigationDestination(icon: Icon(Icons.download_rounded), label: 'Grab'),
              NavigationDestination(icon: Icon(Icons.folder_rounded), label: 'My Downloads'),
              NavigationDestination(icon: Icon(Icons.more_horiz_rounded), label: 'More'),
            ],
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Grab tab
// ---------------------------------------------------------------------------
class GrabTab extends StatefulWidget {
  const GrabTab({super.key});
  @override
  State<GrabTab> createState() => _GrabTabState();
}

class _GrabTabState extends State<GrabTab> {
  final _urlCtrl = TextEditingController();
  bool _busy = false;
  String? _error;
  GrabResult? _result;
  String? _detected;

  // download progress: format label -> 0..1 (null = indeterminate), -1 = done marker handled by record
  final Map<String, double?> _progress = {};
  final Set<String> _done = {};

  @override
  void initState() {
    super.initState();
    _urlCtrl.addListener(() {
      final p = detectPlatform(_urlCtrl.text.trim());
      if (p != _detected) setState(() => _detected = p);
    });
  }

  Future<void> _paste() async {
    final data = await Clipboard.getData('text/plain');
    if (data?.text != null) {
      _urlCtrl.text = data!.text!.trim();
    }
  }

  Future<void> _grab() async {
    final url = _urlCtrl.text.trim();
    if (url.isEmpty || !url.startsWith('http')) {
      setState(() => _error = 'Paste a valid video link first.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
      _result = null;
      _progress.clear();
      _done.clear();
    });
    try {
      final r = await extractLink(url);
      setState(() => _result = r);
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      setState(() => _busy = false);
    }
  }

  Future<void> _download(GrabResult result, GrabFormat f) async {
    setState(() => _progress[f.label] = null);
    try {
      final dir = await getExternalStorageDirectory() ??
          await getApplicationDocumentsDirectory();
      final folder = Directory('${dir.path}/GrabAll');
      if (!await folder.exists()) await folder.create(recursive: true);
      final name =
          '${sanitize(result.title)} (${f.label.replaceAll(' ', '_')}).${f.ext}';
      final file = File('${folder.path}/$name');

      final req = http.Request('GET', Uri.parse(f.url));
      final resp = await http.Client().send(req);
      if (resp.statusCode != 200) {
        throw Exception('Download failed (${resp.statusCode}). The link may have expired — grab it again.');
      }
      final total = resp.contentLength ?? -1;
      var received = 0;
      final sink = file.openWrite();
      await for (final chunk in resp.stream) {
        sink.add(chunk);
        received += chunk.length;
        if (total > 0) {
          setState(() => _progress[f.label] = received / total);
        }
      }
      await sink.close();

      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getStringList('downloads') ?? [];
      raw.insert(
          0,
          jsonEncode(DownloadRecord(
            title: result.title,
            platform: result.platform,
            formatLabel: f.label,
            path: file.path,
            size: received,
            dateMs: DateTime.now().millisecondsSinceEpoch,
          ).toJson()));
      await prefs.setStringList('downloads', raw);
      setState(() {
        _progress.remove(f.label);
        _done.add(f.label);
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Saved to My Downloads')),
        );
      }
    } catch (e) {
      setState(() => _progress.remove(f.label));
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: const LinearGradient(
                colors: [Color(0xFF6D28D9), Color(0xFFDB2777)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('GrabAll',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 30,
                        fontWeight: FontWeight.w800)),
                SizedBox(height: 4),
                Text('All-in-One Video & MP3 Downloader',
                    style: TextStyle(color: Colors.white70, fontSize: 14)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _urlCtrl,
            decoration: InputDecoration(
              hintText: 'Paste a video link here…',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              prefixIcon: const Icon(Icons.link_rounded),
              suffixIcon: IconButton(
                icon: const Icon(Icons.content_paste_rounded),
                onPressed: _paste,
                tooltip: 'Paste',
              ),
            ),
          ),
          if (_detected != null) ...[
            const SizedBox(height: 8),
            Row(children: [
              const Icon(Icons.check_circle, color: Colors.green, size: 18),
              const SizedBox(width: 6),
              Text('$_detected link detected',
                  style: const TextStyle(fontWeight: FontWeight.w600)),
            ]),
          ],
          const SizedBox(height: 12),
          SizedBox(
            height: 52,
            child: FilledButton(
              onPressed: _busy ? null : _grab,
              child: _busy
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.5))
                  : const Text('GRAB IT',
                      style:
                          TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            ),
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.orange.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.orange.shade200),
              ),
              child: Text(_error!,
                  style: TextStyle(color: Colors.orange.shade900)),
            ),
          ],
          if (_result != null) ...[
            const SizedBox(height: 16),
            _resultCard(_result!),
          ],
          const SizedBox(height: 20),
          const Text('Supported platforms',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: kPlatformNames
                .map((n) => Chip(
                      label: Text(n),
                      avatar: const Icon(Icons.play_circle_fill, size: 18),
                    ))
                .toList(),
          ),
          const SizedBox(height: 8),
          const Text(
            'TikTok works fully right now (no watermark + MP3). The engine for the other platforms is being connected — links are already detected.',
            style: TextStyle(color: Colors.black54, fontSize: 12.5),
          ),
        ],
      ),
    );
  }

  Widget _resultCard(GrabResult r) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (r.thumbnail != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(r.thumbnail!,
                    height: 180, width: double.infinity, fit: BoxFit.cover),
              ),
            const SizedBox(height: 10),
            Text(r.title,
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            if (r.uploader != null)
              Text(r.uploader!, style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 10),
            ...r.formats.map((f) {
              final downloading = _progress.containsKey(f.label);
              final done = _done.contains(f.label);
              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        icon: Icon(f.isAudio
                            ? Icons.music_note_rounded
                            : Icons.videocam_rounded),
                        label: Text(done ? '${f.label} — Saved' : f.label),
                        onPressed:
                            (downloading || done) ? null : () => _download(r, f),
                      ),
                    ),
                    if (downloading)
                      LinearProgressIndicator(value: _progress[f.label]),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Downloads tab
// ---------------------------------------------------------------------------
class DownloadsTab extends StatefulWidget {
  const DownloadsTab({super.key});
  @override
  State<DownloadsTab> createState() => _DownloadsTabState();
}

class _DownloadsTabState extends State<DownloadsTab> {
  List<DownloadRecord> _items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('downloads') ?? [];
    setState(() {
      _items = raw
          .map((s) => DownloadRecord.fromJson(
              jsonDecode(s) as Map<String, dynamic>))
          .toList();
    });
  }

  Future<void> _delete(DownloadRecord r) async {
    final f = File(r.path);
    if (await f.exists()) await f.delete();
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('downloads') ?? [];
    raw.removeWhere((s) =>
        (jsonDecode(s) as Map<String, dynamic>)['path'] == r.path);
    await prefs.setStringList('downloads', raw);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: _load,
        child: _items.isEmpty
            ? ListView(children: const [
                SizedBox(height: 120),
                Icon(Icons.folder_open_rounded, size: 64, color: Colors.black26),
                SizedBox(height: 12),
                Center(
                    child: Text('No downloads yet',
                        style: TextStyle(fontSize: 16, color: Colors.black54))),
                Center(
                    child: Text('Grab a link and your files will appear here.',
                        style: TextStyle(color: Colors.black45))),
              ])
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: _items.length,
                itemBuilder: (_, i) {
                  final r = _items[i];
                  final d = DateTime.fromMillisecondsSinceEpoch(r.dateMs);
                  return Card(
                    child: ListTile(
                      leading: Icon(
                          r.formatLabel.contains('MP3')
                              ? Icons.music_note_rounded
                              : Icons.videocam_rounded,
                          color: const Color(0xFF7C3AED)),
                      title: Text(r.title,
                          maxLines: 2, overflow: TextOverflow.ellipsis),
                      subtitle: Text(
                          '${r.platform} • ${r.formatLabel} • ${fmtSize(r.size)}\n${d.day}/${d.month}/${d.year}'),
                      isThreeLine: true,
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline_rounded),
                        onPressed: () => _delete(r),
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// More tab (About)
// ---------------------------------------------------------------------------
class MoreTab extends StatelessWidget {
  const MoreTab({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('About GrabAll',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          const Text(
            'GrabAll is an all-in-one video & MP3 downloader. Paste a public link, pick a quality or MP3, and save it to your Downloads library inside the app.',
            style: TextStyle(color: Colors.black54),
          ),
          const Divider(height: 32),
          const Text('How it works',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          const Text(
            '1. Copy a video link from any app.\n2. Paste it in GrabAll — the platform is detected automatically.\n3. Choose Video (360p / 720p / 1080p) or MP3.\n4. Tap GRAB IT — the file saves to My Downloads.',
            style: TextStyle(color: Colors.black54),
          ),
          const Divider(height: 32),
          const Text('Supported platforms',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          const Text(
            'Instagram, Facebook, TikTok, YouTube, RedNote, Bilibili, X (Twitter), SnackVideo, Likee, Snapchat, Pinterest, Reddit, Vimeo, Dailymotion, SoundCloud, Twitch and Threads. TikTok works fully right now; the engine for the other platforms is being connected.',
            style: TextStyle(color: Colors.black54),
          ),
          const Divider(height: 32),
          const Text(
            'Please only download content you own or have permission to save, and respect the creators and each platform\'s terms.',
            style: TextStyle(color: Colors.black54),
          ),
          const SizedBox(height: 16),
          const Text('Version 1.0.0',
              style: TextStyle(color: Colors.black38, fontSize: 12)),
        ],
      ),
    );
  }
}
