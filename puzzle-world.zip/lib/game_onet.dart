import 'dart:math';
import 'package:flutter/material.dart';
import 'services.dart';
import 'common.dart';

// ===========================================================================
// ONET: connect two matching fruit tiles with a path of max 2 turns.
// Board grows and fruit types increase with level.
// ===========================================================================

const List<String> _fruits = [
  '🍍', '🍊', '🥝', '🍓', '🫐', '🍉', '🍇', '🍑', '🍎', '🍋', '🍒', '🥭'
];

class OnetGame extends StatefulWidget {
  const OnetGame({super.key});
  @override
  State<OnetGame> createState() => _OnetGameState();
}

class _OnetGameState extends State<OnetGame> {
  final _rnd = Random();
  int _level = 1;
  int _cols = 6, _rows = 4;
  List<List<int>> _g = []; // includes 1-cell empty border; 0 = empty, else fruit idx+1
  int? _selX, _selY;
  int _score = 0;
  List<List<int>> _flashPath = [];
  List<int>? _hintA, _hintB;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    _level = await Prefs.level('onet');
    _gen(_level);
  }

  void _gen(int lv) {
    _cols = min(6 + (lv - 1), 10);
    _rows = min(4 + ((lv - 1) ~/ 2), 7);
    if ((_cols * _rows) % 2 == 1) _rows++;
    final types = min(5 + lv, _fruits.length);
    final total = _cols * _rows;
    final faces = <int>[];
    for (int i = 0; i < total ~/ 2; i++) {
      final f = _rnd.nextInt(types);
      faces.add(f);
      faces.add(f);
    }
    faces.shuffle(_rnd);
    _g = List.generate(_rows + 2, (_) => List.filled(_cols + 2, 0));
    int k = 0;
    for (int y = 1; y <= _rows; y++) {
      for (int x = 1; x <= _cols; x++) {
        _g[y][x] = faces[k++] + 1;
      }
    }
    setState(() {
      _selX = null;
      _selY = null;
      _flashPath = [];
      _hintA = null;
      _hintB = null;
    });
    _ensureMoves();
  }

  int get _remaining {
    int c = 0;
    for (final row in _g) {
      for (final v in row) {
        if (v != 0) c++;
      }
    }
    return c;
  }

  /// BFS path with at most 2 turns. Returns list of points or null.
  List<List<int>>? _connect(int x1, int y1, int x2, int y2) {
    final h = _rows + 2, w = _cols + 2;
    // state: index, dir(0..3), turns; Dijkstra/BFS by turns then steps
    final visited = List.generate(
        h, (_) => List.generate(w, (_) => List.filled(4, 99)));
    final prev = <String, String>{};
    final queue = <List<int>>[]; // x,y,dir,turns
    for (int d = 0; d < 4; d++) {
      visited[y1][x1][d] = 0;
      queue.add([x1, y1, d, 0]);
    }
    const dirs = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1]
    ];
    String key(int x, int y, int d) => '$x,$y,$d';
    List<int>? found;
    while (queue.isNotEmpty) {
      queue.sort((a, b) => a[3] - b[3]);
      final cur = queue.removeAt(0);
      final x = cur[0], y = cur[1], d = cur[2], t = cur[3];
      if (x == x2 && y == y2) {
        found = cur;
        break;
      }
      for (int nd = 0; nd < 4; nd++) {
        final nt = t + (nd == d ? 0 : 1);
        if (nt > 2) continue;
        final nx = x + dirs[nd][0], ny = y + dirs[nd][1];
        if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
        final isTarget = nx == x2 && ny == y2;
        if (!isTarget && _g[ny][nx] != 0) continue;
        if (visited[ny][nx][nd] <= nt) continue;
        visited[ny][nx][nd] = nt;
        prev[key(nx, ny, nd)] = key(x, y, d);
        queue.add([nx, ny, nd, nt]);
      }
    }
    if (found == null) return null;
    final path = <List<int>>[];
    var k = key(found[0], found[1], found[2]);
    var cx = found[0], cy = found[1];
    path.add([cx, cy]);
    while (prev.containsKey(k)) {
      final parts = prev[k]!.split(',');
      cx = int.parse(parts[0]);
      cy = int.parse(parts[1]);
      path.add([cx, cy]);
      k = prev[k]!;
      if (cx == x1 && cy == y1) break;
    }
    return path.reversed.toList();
  }

  List<List<int>>? _findPair() {
    final cells = <List<int>>[];
    for (int y = 1; y <= _rows; y++) {
      for (int x = 1; x <= _cols; x++) {
        if (_g[y][x] != 0) cells.add([x, y, _g[y][x]]);
      }
    }
    for (int i = 0; i < cells.length; i++) {
      for (int j = i + 1; j < cells.length; j++) {
        if (cells[i][2] != cells[j][2]) continue;
        final p = _connect(cells[i][0], cells[i][1], cells[j][0], cells[j][1]);
        if (p != null) {
          return [cells[i], cells[j]];
        }
      }
    }
    return null;
  }

  void _ensureMoves() {
    if (_remaining == 0) return;
    if (_findPair() == null) {
      // shuffle faces among remaining cells
      final faces = <int>[];
      final spots = <List<int>>[];
      for (int y = 1; y <= _rows; y++) {
        for (int x = 1; x <= _cols; x++) {
          if (_g[y][x] != 0) {
            faces.add(_g[y][x]);
            spots.add([x, y]);
          }
        }
      }
      int tries = 0;
      do {
        faces.shuffle(_rnd);
        for (int i = 0; i < spots.length; i++) {
          _g[spots[i][1]][spots[i][0]] = faces[i];
        }
        tries++;
      } while (_findPair() == null && tries < 30);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('No moves left — tiles shuffled!'),
          duration: Duration(seconds: 1),
        ));
      }
    }
  }

  void _tap(int x, int y) {
    final v = _g[y][x];
    if (v == 0) return;
    Sfx.play('click');
    if (_selX == null) {
      setState(() {
        _selX = x;
        _selY = y;
        _hintA = null;
        _hintB = null;
      });
      return;
    }
    if (_selX == x && _selY == y) {
      setState(() {
        _selX = null;
        _selY = null;
      });
      return;
    }
    if (_g[_selY!][_selX!] == v) {
      final path = _connect(_selX!, _selY!, x, y);
      if (path != null) {
        setState(() {
          _flashPath = path;
          _g[_selY!][_selX!] = 0;
          _g[y][x] = 0;
          _selX = null;
          _selY = null;
          _score += 10;
        });
        Sfx.play('pop');
        Sfx.vibe();
        Future.delayed(const Duration(milliseconds: 260), () {
          if (mounted) setState(() => _flashPath = []);
        });
        if (_remaining == 0) {
          Prefs.saveBest('onet', _score);
          Prefs.saveLevel('onet', _level + 1);
          Future.delayed(const Duration(milliseconds: 350), () {
            if (!mounted) return;
            showLevelComplete(context,
                title: 'Level $_level Complete! 🎉',
                message: 'Score: $_score',
                onNext: () {
                  setState(() {
                    _level++;
                    _score = 0;
                  });
                  _gen(_level);
                },
                onReplay: () => _gen(_level));
          });
        } else {
          _ensureMoves();
        }
        return;
      }
    }
    setState(() {
      _selX = x;
      _selY = y;
    });
  }

  Future<void> _hint() async {
    final ok = await HintBank.useHint(context);
    if (!ok || !mounted) return;
    final pair = _findPair();
    if (pair != null) {
      setState(() {
        _hintA = pair[0];
        _hintB = pair[1];
      });
      Sfx.play('blip');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF5D4A4A), Color(0xFF3E3232)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              GameHeader(
                title: 'Onet — Level $_level',
                trailing: HintButton(onHint: _hint),
              ),
              Text('Score: $_score   •   Tiles: $_remaining',
                  style: const TextStyle(
                      color: Colors.white70, fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              Expanded(
                child: Center(
                  child: AspectRatio(
                    aspectRatio: _cols / _rows,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      child: Stack(
                        children: [
                          GridView.builder(
                            physics: const NeverScrollableScrollPhysics(),
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: _cols,
                              crossAxisSpacing: 5,
                              mainAxisSpacing: 5,
                            ),
                            itemCount: _cols * _rows,
                            itemBuilder: (_, i) {
                              final x = i % _cols + 1;
                              final y = i ~/ _cols + 1;
                              final v = _g[y][x];
                              if (v == 0) return const SizedBox.shrink();
                              final selected = _selX == x && _selY == y;
                              final hinted = (_hintA != null &&
                                      _hintA![0] == x &&
                                      _hintA![1] == y) ||
                                  (_hintB != null &&
                                      _hintB![0] == x &&
                                      _hintB![1] == y);
                              return GestureDetector(
                                onTap: () => _tap(x, y),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFFFF7E8),
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                      color: selected
                                          ? const Color(0xFFF5B921)
                                          : hinted
                                              ? const Color(0xFF35C759)
                                              : Colors.transparent,
                                      width: 3,
                                    ),
                                    boxShadow: const [
                                      BoxShadow(
                                          color: Colors.black38,
                                          blurRadius: 3,
                                          offset: Offset(0, 2))
                                    ],
                                  ),
                                  child: Center(
                                    child: FittedBox(
                                      child: Text(_fruits[v - 1],
                                          style: const TextStyle(fontSize: 34)),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                          if (_flashPath.isNotEmpty)
                            Positioned.fill(
                              child: CustomPaint(
                                painter: _PathPainter(
                                    path: _flashPath,
                                    cols: _cols,
                                    rows: _rows),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}

class _PathPainter extends CustomPainter {
  _PathPainter({required this.path, required this.cols, required this.rows});
  final List<List<int>> path;
  final int cols, rows;

  @override
  void paint(Canvas canvas, Size size) {
    final cw = size.width / cols;
    final ch = size.height / rows;
    final paint = Paint()
      ..color = const Color(0xFFF5B921)
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final p = Path();
    for (int i = 0; i < path.length; i++) {
      // path coords include border offset of 1
      final cx = (path[i][0] - 1) * cw + cw / 2;
      final cy = (path[i][1] - 1) * ch + ch / 2;
      if (i == 0) {
        p.moveTo(cx, cy);
      } else {
        p.lineTo(cx, cy);
      }
    }
    canvas.drawPath(p, paint);
  }

  @override
  bool shouldRepaint(covariant _PathPainter old) => true;
}
