import 'dart:math';
import 'package:flutter/material.dart';
import 'services.dart';
import 'common.dart';

// ===========================================================================
// ONE LINE: fill every square with one single stroke (Hamiltonian path).
// Shapes + solutions generated per level; shapes grow with level.
// ===========================================================================

class OneLineGame extends StatefulWidget {
  const OneLineGame({super.key});
  @override
  State<OneLineGame> createState() => _OneLineGameState();
}

class _OneLineGameState extends State<OneLineGame> {
  final _rnd = Random();
  int _level = 1;
  int _w = 4, _h = 4;
  Set<int> _shape = {};
  List<int> _solution = [];
  List<int> _path = [];
  int? _hintCell;
  bool _won = false;

  int _id(int x, int y) => y * _w + x;
  int _x(int id) => id % _w;
  int _y(int id) => id ~/ _w;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    _level = await Prefs.level('oneline');
    _gen(_level);
  }

  void _gen(int lv) {
    final target = min(7 + (lv - 1) * 2, 30); // 7,9,11,...30 cells
    for (int attempt = 0; attempt < 60; attempt++) {
      // grow a blob
      _w = 6;
      _h = 6;
      final shape = <int>{_id(2, 2)};
      final frontier = <int>[];
      void addFrontier(int id) {
        for (final d in const [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1]
        ]) {
          final nx = _x(id) + d[0], ny = _y(id) + d[1];
          if (nx >= 0 && ny >= 0 && nx < _w && ny < _h) {
            final nid = _id(nx, ny);
            if (!shape.contains(nid) && !frontier.contains(nid)) {
              frontier.add(nid);
            }
          }
        }
      }

      addFrontier(_id(2, 2));
      while (shape.length < target && frontier.isNotEmpty) {
        final pick = frontier.removeAt(_rnd.nextInt(frontier.length));
        shape.add(pick);
        addFrontier(pick);
      }
      if (shape.length < target) continue;
      final sol = _hamiltonian(shape);
      if (sol != null) {
        // trim grid bounds to shape
        setState(() {
          _shape = shape;
          _solution = sol;
          _path = [];
          _hintCell = null;
          _won = false;
        });
        return;
      }
    }
    // fallback: plain 3x3 snake
    _w = 3;
    _h = 3;
    setState(() {
      _shape = {for (int i = 0; i < 9; i++) i};
      _solution = [0, 1, 2, 5, 4, 3, 6, 7, 8];
      _path = [];
      _won = false;
    });
  }

  List<int>? _hamiltonian(Set<int> shape) {
    final cells = shape.toList();
    final start = cells[_rnd.nextInt(cells.length)];
    final visited = <int>{start};
    final path = [start];
    int steps = 0;
    bool dfs(int cur) {
      if (path.length == shape.length) return true;
      if (++steps > 20000) return false;
      final nbrs = <int>[];
      for (final d in const [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1]
      ]) {
        final nx = _x(cur) + d[0], ny = _y(cur) + d[1];
        if (nx < 0 || ny < 0 || nx >= _w || ny >= _h) continue;
        final nid = _id(nx, ny);
        if (shape.contains(nid) && !visited.contains(nid)) nbrs.add(nid);
      }
      // Warnsdorff: fewest onward moves first
      nbrs.sort((a, b) {
        int deg(int id) => const [
              [1, 0],
              [-1, 0],
              [0, 1],
              [0, -1]
            ]
                .where((d) {
                  final nx = _x(id) + d[0], ny = _y(id) + d[1];
                  if (nx < 0 || ny < 0 || nx >= _w || ny >= _h) return false;
                  final nid = _id(nx, ny);
                  return shape.contains(nid) && !visited.contains(nid);
                })
                .length;
        return deg(a) - deg(b);
      });
      for (final nb in nbrs) {
        visited.add(nb);
        path.add(nb);
        if (dfs(nb)) return true;
        visited.remove(nb);
        path.removeLast();
        if (steps > 20000) return false;
      }
      return false;
    }

    return dfs(start) ? path : null;
  }

  void _onDrag(Offset local, double cell) {
    if (_won) return;
    final x = (local.dx / cell).floor();
    final y = (local.dy / cell).floor();
    if (x < 0 || y < 0 || x >= _w || y >= _h) return;
    final id = _id(x, y);
    if (!_shape.contains(id)) return;
    if (_path.isEmpty) {
      if (id == _solution.first) {
        setState(() => _path = [id]);
        Sfx.play('blip');
      }
      return;
    }
    final last = _path.last;
    if (id == last) return;
    // drag back = undo
    if (_path.length >= 2 && id == _path[_path.length - 2]) {
      setState(() => _path.removeLast());
      Sfx.play('click');
      return;
    }
    final adjacent = (_x(id) - _x(last)).abs() + (_y(id) - _y(last)).abs() == 1;
    if (adjacent && !_path.contains(id)) {
      setState(() {
        _path.add(id);
        _hintCell = null;
      });
      Sfx.play('blip');
      Sfx.vibe();
      if (_path.length == _shape.length) {
        _won = true;
        Sfx.play('win');
        Prefs.saveLevel('oneline', _level + 1);
        Future.delayed(const Duration(milliseconds: 400), () {
          if (!mounted) return;
          showLevelComplete(context,
              title: 'Level $_level Complete! 🎉',
              message: 'Filled in one line!',
              onNext: () {
                setState(() => _level++);
                _gen(_level);
              },
              onReplay: () => _gen(_level));
        });
      }
    }
  }

  Future<void> _hint() async {
    final ok = await HintBank.useHint(context);
    if (!ok || !mounted) return;
    // if current path matches solution prefix, show next cell
    bool prefix = _path.length <= _solution.length;
    if (prefix) {
      for (int i = 0; i < _path.length; i++) {
        if (_path[i] != _solution[i]) prefix = false;
      }
    }
    if (prefix && _path.length < _solution.length) {
      setState(() => _hintCell = _solution[_path.length]);
      Sfx.play('blip');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Hint: drag back to undo — your line went off track'),
        duration: Duration(seconds: 2),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF263238),
      body: SafeArea(
        child: Column(
          children: [
            GameHeader(
              title: 'LEVEL $_level',
              trailing: IconButton(
                icon: const Icon(Icons.replay, color: Colors.white, size: 27),
                onPressed: () {
                  Sfx.play('click');
                  _gen(_level);
                },
              ),
            ),
            // progress bar like the original
            Padding(
              padding: const EdgeInsets.fromLTRB(40, 6, 40, 0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Stack(
                  children: [
                    Container(height: 26, color: Colors.white24),
                    FractionallySizedBox(
                      widthFactor:
                          _shape.isEmpty ? 0 : _path.length / _shape.length,
                      child: Container(
                          height: 26, color: const Color(0xFFF5A623)),
                    ),
                    Positioned.fill(
                      child: Center(
                        child: Text('${_path.length}/${_shape.length}',
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w800)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: Center(
                child: LayoutBuilder(builder: (context, cons) {
                  final size = min(cons.maxWidth - 48, cons.maxHeight - 120);
                  final cell = size / 6; // grid is 6x6 area
                  return GestureDetector(
                    onPanStart: (d) => _onDrag(d.localPosition, cell),
                    onPanUpdate: (d) => _onDrag(d.localPosition, cell),
                    child: Container(
                      width: size,
                      height: size,
                      color: Colors.transparent,
                      child: CustomPaint(
                        painter: _OneLinePainter(
                          w: _w,
                          h: _h,
                          shape: _shape,
                          path: _path,
                          start: _solution.isEmpty ? -1 : _solution.first,
                          hintCell: _hintCell,
                        ),
                        size: Size(size, size),
                      ),
                    ),
                  );
                }),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 26),
              child: HintButton(onHint: _hint),
            ),
          ],
        ),
      ),
    );
  }
}

class _OneLinePainter extends CustomPainter {
  _OneLinePainter(
      {required this.w,
      required this.h,
      required this.shape,
      required this.path,
      required this.start,
      required this.hintCell});
  final int w, h;
  final Set<int> shape;
  final List<int> path;
  final int start;
  final int? hintCell;

  @override
  void paint(Canvas canvas, Size size) {
    final cell = size.width / 6;
    final gap = cell * 0.08;
    // shape cells
    for (final id in shape) {
      final x = id % w, y = id ~/ w;
      final filled = path.contains(id);
      final r = Rect.fromLTWH(
          x * cell + gap, y * cell + gap, cell - gap * 2, cell - gap * 2);
      canvas.drawRRect(
        RRect.fromRectAndRadius(r, Radius.circular(cell * 0.16)),
        Paint()
          ..color = filled
              ? const Color(0xFF2FD35F)
              : const Color(0xFF5B6B7A).withOpacity(0.55),
      );
      if (id == hintCell) {
        canvas.drawRRect(
          RRect.fromRectAndRadius(r, Radius.circular(cell * 0.16)),
          Paint()
            ..color = Colors.white
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3.5,
        );
      }
    }
    // path line
    if (path.length > 1) {
      final paint = Paint()
        ..color = const Color(0xFF7CF29A)
        ..strokeWidth = cell * 0.34
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round;
      final p = Path();
      for (int i = 0; i < path.length; i++) {
        final cx = (path[i] % w) * cell + cell / 2;
        final cy = (path[i] ~/ w) * cell + cell / 2;
        if (i == 0) {
          p.moveTo(cx, cy);
        } else {
          p.lineTo(cx, cy);
        }
      }
      canvas.drawPath(p, paint);
    }
    // start dot
    if (start >= 0 && path.isEmpty) {
      final cx = (start % w) * cell + cell / 2;
      final cy = (start ~/ w) * cell + cell / 2;
      canvas.drawCircle(
          Offset(cx, cy), cell * 0.16, Paint()..color = Colors.white);
    }
    // current head
    if (path.isNotEmpty) {
      final last = path.last;
      final cx = (last % w) * cell + cell / 2;
      final cy = (last ~/ w) * cell + cell / 2;
      canvas.drawCircle(
          Offset(cx, cy), cell * 0.20, Paint()..color = Colors.white70);
    }
  }

  @override
  bool shouldRepaint(covariant _OneLinePainter old) => true;
}
