import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'services.dart';
import 'common.dart';

// ===========================================================================
// FRUIT MERGE: drop fruits, two of a kind merge into the next bigger fruit.
// Reach the level's target score before the box overflows.
// ===========================================================================

const List<String> _fruitEmoji = [
  '🫐', '🍓', '🍒', '🍋', '🍑', '🍊', '🍎', '🍍', '🥥', '🍈', '🍉'
];
const List<Color> _fruitColor = [
  Color(0xFF5B6ABF), Color(0xFFE5484D), Color(0xFFB0413E), Color(0xFFF2C618),
  Color(0xFFFF9E8A), Color(0xFFF07D1A), Color(0xFFE03131), Color(0xFFF5B921),
  Color(0xFF8D6E63), Color(0xFFA8C686), Color(0xFF2F9E44),
];
double _radius(int tier) => 15 + tier * 4.7;

class _Fruit {
  _Fruit(this.pos, this.tier);
  Offset pos;
  Offset vel = Offset.zero;
  final int tier;
  double get r => _radius(tier);
  double danger = 0;
}

class FruitMergeGame extends StatefulWidget {
  const FruitMergeGame({super.key});
  @override
  State<FruitMergeGame> createState() => _FruitMergeGameState();
}

class _FruitMergeGameState extends State<FruitMergeGame>
    with SingleTickerProviderStateMixin {
  final _rnd = Random();
  final List<_Fruit> _fruits = [];
  late final Ticker _ticker;
  Duration _last = Duration.zero;
  Size _box = const Size(340, 400);
  int _level = 1;
  int _score = 0;
  int _best = 0;
  int _current = 0;
  int _next = 0;
  double _aimX = 170;
  double _cooldown = 0;
  bool _over = false;
  bool _reviveUsed = false;
  double? _hintX;

  int get _target => 400 + (_level - 1) * 350;

  @override
  void initState() {
    super.initState();
    _current = _rnd.nextInt(5);
    _next = _rnd.nextInt(5);
    _ticker = createTicker(_tick);
    _ticker.start();
    _load();
  }

  Future<void> _load() async {
    _level = await Prefs.level('fruit');
    _best = await Prefs.best('fruit');
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  void _tick(Duration now) {
    if (_last == Duration.zero) {
      _last = now;
      return;
    }
    double dt = (now - _last).inMicroseconds / 1e6;
    _last = now;
    if (dt > 0.033) dt = 0.033;
    if (_over) return;
    if (_cooldown > 0) _cooldown -= dt;
    _step(dt);
    if (mounted) setState(() {});
  }

  void _step(double dt) {
    const g = 1500.0;
    final w = _box.width, h = _box.height;
    // integrate
    for (final f in _fruits) {
      f.vel = Offset(f.vel.dx, f.vel.dy + g * dt);
      f.pos += f.vel * dt;
      if (f.pos.dx < f.r) {
        f.pos = Offset(f.r, f.pos.dy);
        f.vel = Offset(-f.vel.dx * 0.3, f.vel.dy);
      }
      if (f.pos.dx > w - f.r) {
        f.pos = Offset(w - f.r, f.pos.dy);
        f.vel = Offset(-f.vel.dx * 0.3, f.vel.dy);
      }
      if (f.pos.dy > h - f.r) {
        f.pos = Offset(f.pos.dx, h - f.r);
        f.vel = Offset(f.vel.dx * 0.9, 0);
      }
      if (f.pos.dy < f.r) {
        f.pos = Offset(f.pos.dx, f.r);
        f.vel = Offset(f.vel.dx, max(0, f.vel.dy));
      }
    }
    // collisions + merges (2 substeps)
    for (int s = 0; s < 2; s++) {
      for (int i = 0; i < _fruits.length; i++) {
        for (int j = i + 1; j < _fruits.length; j++) {
          final a = _fruits[i], b = _fruits[j];
          final d = b.pos - a.pos;
          final dist = d.distance;
          final minD = a.r + b.r;
          if (dist >= minD || dist == 0) continue;
          if (a.tier == b.tier && a.tier < 10) {
            // merge!
            final mid = (a.pos + b.pos) / 2;
            final nf = _Fruit(mid, a.tier + 1);
            nf.vel = (a.vel + b.vel) / 2;
            _fruits.removeAt(j);
            _fruits.removeAt(i);
            _fruits.add(nf);
            _score += (a.tier + 2) * 5;
            Sfx.play('blip');
            Sfx.vibe();
            if (_score >= _target) _levelComplete();
            return;
          }
          final nrm = d / dist;
          final overlap = (minD - dist) / 2;
          a.pos -= nrm * overlap;
          b.pos += nrm * overlap;
          final rel = (b.vel - a.vel).dot(nrm);
          if (rel < 0) {
            final imp = nrm * (-rel * 0.6);
            a.vel -= imp;
            b.vel += imp;
          }
        }
      }
    }
    // danger: fruit sitting above the line
    final lineY = h * 0.16;
    bool dangerNow = false;
    for (final f in _fruits) {
      if (f.pos.dy - f.r < lineY && f.vel.dy.abs() < 60) {
        f.danger += dt;
        if (f.danger > 1.6) dangerNow = true;
      } else {
        f.danger = max(0, f.danger - dt * 2);
      }
    }
    if (dangerNow) _gameOver();
  }

  void _drop() {
    if (_cooldown > 0 || _over) return;
    final r = _radius(_current);
    final x = _aimX.clamp(r, _box.width - r);
    _fruits.add(_Fruit(Offset(x, r + 2), _current));
    _current = _next;
    _next = _rnd.nextInt(5);
    _cooldown = 0.55;
    _hintX = null;
    Sfx.play('pop');
  }

  void _levelComplete() {
    _over = true;
    Prefs.saveBest('fruit', _score);
    Prefs.saveLevel('fruit', _level + 1);
    Future.delayed(const Duration(milliseconds: 300), () {
      if (!mounted) return;
      showLevelComplete(context,
          title: 'Level $_level Complete! 🎉',
          message: 'Target $_target reached — Score: $_score',
          onNext: () {
            setState(() {
              _level++;
              _fruits.clear();
              _score = 0;
              _over = false;
              _reviveUsed = false;
            });
          },
          onReplay: () {
            setState(() {
              _fruits.clear();
              _score = 0;
              _over = false;
            });
          });
    });
  }

  Future<void> _gameOver() async {
    _over = true;
    Sfx.play('lose');
    Prefs.saveBest('fruit', _score);
    if (!_reviveUsed && mounted) {
      final revive = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          backgroundColor: const Color(0xFF7A4A21),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: const Text('Box is full!',
              textAlign: TextAlign.center,
              style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
          content: const Text(
              'Watch an ad to remove the smallest fruits and keep playing?',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70)),
          actionsAlignment: MainAxisAlignment.center,
          actions: [
            TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('No thanks',
                    style: TextStyle(color: Colors.white54))),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFF5B921)),
              onPressed: () => Navigator.of(context).pop(true),
              icon: const Icon(Icons.play_circle_fill, color: Colors.white),
              label: const Text('Revive',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w800)),
            ),
          ],
        ),
      );
      if (revive == true && mounted) {
        final ok = await showRewardedAd(context);
        if (ok) {
          setState(() {
            _reviveUsed = true;
            _over = false;
            _fruits.removeWhere((f) => f.tier <= 1);
            for (final f in _fruits) {
              f.danger = 0;
            }
          });
          return;
        }
      }
    }
    if (!mounted) return;
    showAdBreak(context);
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF7A4A21),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('Game Over',
            textAlign: TextAlign.center,
            style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 25)),
        content: Text('Score: $_score\nBest: $_best',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70, fontSize: 17)),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
              },
              child: const Text('Home',
                  style: TextStyle(color: Colors.white54))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF35C759)),
            onPressed: () {
              Navigator.of(context).pop();
              setState(() {
                _fruits.clear();
                _score = 0;
                _over = false;
                _reviveUsed = false;
              });
            },
            child: const Text('Play Again',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  Future<void> _hint() async {
    final ok = await HintBank.useHint(context);
    if (!ok || !mounted) return;
    // suggest x above a same-tier fruit
    for (final f in _fruits) {
      if (f.tier == _current) {
        setState(() => _hintX = f.pos.dx);
        Sfx.play('blip');
        return;
      }
    }
    setState(() => _hintX = _box.width / 2);
    Sfx.play('blip');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFF7C873), Color(0xFFF2A65A)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              GameHeader(
                title: 'Fruit Merge',
                trailing: HintButton(onHint: _hint),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Text('SCORE  $_score',
                        style: const TextStyle(
                            color: Color(0xFF7A4A21),
                            fontWeight: FontWeight.w900,
                            fontSize: 17)),
                    const Spacer(),
                    Text('TARGET  $_target',
                        style: const TextStyle(
                            color: Color(0xFF7A4A21),
                            fontWeight: FontWeight.w800)),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                          color: Colors.white70,
                          borderRadius: BorderRadius.circular(14)),
                      child: Text('Next ${_fruitEmoji[_next]}',
                          style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              color: Color(0xFF7A4A21))),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: LayoutBuilder(builder: (context, cons) {
                  final bw = min(cons.maxWidth - 28, 430.0);
                  final bh = min(cons.maxHeight - 90, bw * 1.18);
                  _box = Size(bw, bh);
                  return Center(
                    child: GestureDetector(
                      onPanUpdate: (d) {
                        final box = context.findRenderObject() as RenderBox?;
                        if (box == null) return;
                        final local = box.globalToLocal(d.globalPosition);
                        setState(() =>
                            _aimX = (local.dx - (cons.maxWidth - bw) / 2)
                                .clamp(0, bw));
                      },
                      onTapUp: (_) => _drop(),
                      onPanEnd: (_) => _drop(),
                      child: Container(
                        width: bw,
                        height: bh,
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFF3D6).withOpacity(0.55),
                          border: Border.all(
                              color: const Color(0xFFD98E4A), width: 3),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: CustomPaint(
                            painter: _FruitPainter(
                              fruits: _fruits,
                              aimX: _aimX,
                              current: _current,
                              cooldown: _cooldown,
                              hintX: _hintX,
                            ),
                            size: Size(bw, bh),
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
              // evolution bar
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 4, 10, 14),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    for (int i = 0; i < _fruitEmoji.length; i++)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 1.5),
                        child: Text(_fruitEmoji[i],
                            style: TextStyle(fontSize: 15 + i * 1.6)),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FruitPainter extends CustomPainter {
  _FruitPainter({
    required this.fruits,
    required this.aimX,
    required this.current,
    required this.cooldown,
    required this.hintX,
  });
  final List<_Fruit> fruits;
  final double aimX;
  final int current;
  final double cooldown;
  final double? hintX;

  @override
  void paint(Canvas canvas, Size size) {
    // danger line
    final lineY = size.height * 0.16;
    canvas.drawLine(
        Offset(0, lineY),
        Offset(size.width, lineY),
        Paint()
          ..color = Colors.red.withOpacity(0.45)
          ..strokeWidth = 2);
    // aim guide
    final r = _radius(current);
    final ax = aimX.clamp(r, size.width - r);
    if (cooldown <= 0) {
      final guide = Paint()
        ..color = Colors.brown.withOpacity(0.35)
        ..strokeWidth = 2;
      for (double y = r * 2 + 8; y < size.height; y += 16) {
        canvas.drawCircle(Offset(ax, y), 2.2, guide);
      }
      _drawFruit(canvas, Offset(ax, r + 2), current, 0.85);
    }
    if (hintX != null) {
      canvas.drawLine(
          Offset(hintX!, 0),
          Offset(hintX!, size.height),
          Paint()
            ..color = const Color(0xFF35C759)
            ..strokeWidth = 3);
    }
    for (final f in fruits) {
      _drawFruit(canvas, f.pos, f.tier, 1.0);
    }
  }

  void _drawFruit(Canvas canvas, Offset c, int tier, double alpha) {
    final r = _radius(tier);
    canvas.drawCircle(
        c,
        r,
        Paint()..color = _fruitColor[tier].withOpacity(alpha));
    canvas.drawCircle(
        c,
        r,
        Paint()
          ..color = Colors.black.withOpacity(0.12 * alpha)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2);
    final tp = TextPainter(
      text: TextSpan(
          text: _fruitEmoji[tier],
          style: TextStyle(fontSize: r * 1.25)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, c - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant _FruitPainter old) => true;
}
