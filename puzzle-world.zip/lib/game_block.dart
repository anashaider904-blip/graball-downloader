import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'services.dart';
import 'common.dart';

// ===========================================================================
// BLOCK BLAST style flagship game
// 8x8 board, tray of 3, drag with floating piece + ghost, combos, praise,
// particles, one ad revive per game.
// ===========================================================================

class Piece {
  Piece(this.cells, this.color);
  final List<List<int>> cells;
  final int color;
  int get w => cells.map((c) => c[0]).reduce(max) + 1;
  int get h => cells.map((c) => c[1]).reduce(max) + 1;
}

List<List<int>> _norm(List<List<int>> s) {
  final mx = s.map((c) => c[0]).reduce(min);
  final my = s.map((c) => c[1]).reduce(min);
  final out = s.map((c) => [c[0] - mx, c[1] - my]).toList();
  out.sort((a, b) => a[1] != b[1] ? a[1] - b[1] : a[0] - b[0]);
  return out;
}

List<List<int>> _rot(List<List<int>> s) {
  final h = s.map((c) => c[1]).reduce(max);
  return _norm(s.map((c) => [h - c[1], c[0]]).toList());
}

String _key(List<List<int>> s) => s.map((c) => '${c[0]},${c[1]}').join(';');

List<List<List<int>>> _allRotations(List<List<int>> base) {
  final seen = <String>{};
  final out = <List<List<int>>>[];
  var cur = _norm(base);
  for (int i = 0; i < 4; i++) {
    if (seen.add(_key(cur))) out.add(cur);
    cur = _rot(cur);
  }
  return out;
}

final List<List<List<int>>> _shapePool = () {
  final bases = <List<List<int>>>[
    [[0, 0]],
    [[0, 0], [1, 0]],
    [[0, 0], [1, 0], [2, 0]],
    [[0, 0], [1, 0], [2, 0], [3, 0]],
    [[0, 0], [1, 0], [2, 0], [3, 0], [4, 0]],
    [[0, 0], [1, 0], [0, 1], [1, 1]], // 2x2
    [[0, 0], [1, 0], [2, 0], [0, 1], [1, 1], [2, 1]], // 2x3 rect
    [[0, 0], [1, 0], [2, 0], [0, 1], [1, 1], [2, 1], [0, 2], [1, 2], [2, 2]], // 3x3
    [[0, 0], [0, 1], [1, 1]], // corner 3
    [[0, 0], [0, 1], [0, 2], [1, 2]], // L4
    [[0, 0], [0, 1], [0, 2], [1, 2], [2, 2]], // L5
    [[0, 0], [1, 0], [2, 0], [1, 1]], // T
    [[1, 0], [2, 0], [0, 1], [1, 1]], // S
    [[0, 0], [1, 1]], // diagonal 2
    [[0, 0], [1, 1], [2, 2]], // diagonal 3
  ];
  final out = <List<List<int>>>[];
  for (final b in bases) {
    out.addAll(_allRotations(b));
  }
  return out;
}();

class _Particle {
  _Particle(this.x, this.y, this.vx, this.vy, this.color, this.life);
  double x, y, vx, vy, life;
  final Color color;
}

class _FloatText {
  _FloatText(this.x, this.y, this.text);
  final double x, y;
  final String text;
  double life = 1;
}

class BlockBlastGame extends StatefulWidget {
  const BlockBlastGame({super.key});
  @override
  State<BlockBlastGame> createState() => _BlockBlastGameState();
}

class _BlockBlastGameState extends State<BlockBlastGame> {
  static const int n = 8;
  final _rnd = Random();
  List<List<int>> _board = List.generate(n, (_) => List.filled(n, 0));
  List<Piece?> _tray = [null, null, null];
  int _score = 0;
  int _best = 0;
  int _combo = 1; // internal multiplier K
  int _missStreak = 0;
  int _dealCount = 0;
  bool _reviveUsed = false;
  bool _busy = false;
  bool _over = false;

  // drag state
  int? _dragIdx;
  Offset _dragPos = Offset.zero;
  int? _targetX, _targetY;
  final GlobalKey _boardKey = GlobalKey();
  final GlobalKey _rootKey = GlobalKey();
  double _cell = 40;

  // effects
  final Set<int> _clearing = {};
  final List<_Particle> _particles = [];
  final List<_FloatText> _floats = [];
  Timer? _fxTimer;
  String _praise = '';
  int _praiseKey = 0;
  int? _hintX, _hintY, _hintIdx;

  @override
  void initState() {
    super.initState();
    _loadBest();
    _deal();
  }

  @override
  void dispose() {
    _fxTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadBest() async {
    final b = await Prefs.best('block');
    if (mounted) setState(() => _best = b);
  }

  Piece _randomPiece() {
    // dealer gets a bit harder as score grows: more big pieces
    final hard = _score > 1500;
    List<List<int>> shape;
    do {
      shape = _shapePool[_rnd.nextInt(_shapePool.length)];
    } while (!hard && shape.length >= 9 && _rnd.nextDouble() < 0.7);
    return Piece(shape, 1 + _rnd.nextInt(8));
  }

  void _deal() {
    _dealCount++;
    _tray = [_randomPiece(), _randomPiece(), _randomPiece()];
  }

  bool _fits(Piece p, int ox, int oy) {
    for (final c in p.cells) {
      final x = ox + c[0], y = oy + c[1];
      if (x < 0 || y < 0 || x >= n || y >= n || _board[y][x] != 0) return false;
    }
    return true;
  }

  bool _anyFit(Piece p) {
    for (int y = 0; y < n; y++) {
      for (int x = 0; x < n; x++) {
        if (_fits(p, x, y)) return true;
      }
    }
    return false;
  }

  void _startFx() {
    _fxTimer?.cancel();
    _fxTimer = Timer.periodic(const Duration(milliseconds: 16), (_) {
      if (!mounted) return;
      bool alive = false;
      for (final p in _particles) {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.15;
        p.life -= 0.03;
        if (p.life > 0) alive = true;
      }
      for (final f in _floats) {
        f.life -= 0.025;
        if (f.life > 0) alive = true;
      }
      _particles.removeWhere((p) => p.life <= 0);
      _floats.removeWhere((f) => f.life <= 0);
      setState(() {});
      if (!alive && _particles.isEmpty && _floats.isEmpty) _fxTimer?.cancel();
    });
  }

  void _burst(double cx, double cy, int colorIdx) {
    final base = kBlockBase[colorIdx];
    for (int i = 0; i < 10; i++) {
      final a = _rnd.nextDouble() * pi * 2;
      final sp = 1 + _rnd.nextDouble() * 3.2;
      _particles.add(_Particle(
          cx, cy, cos(a) * sp, sin(a) * sp - 1.5, base, 0.7 + _rnd.nextDouble() * 0.5));
    }
    _startFx();
  }

  void _place(int idx, int ox, int oy) {
    final p = _tray[idx]!;
    setState(() {
      for (final c in p.cells) {
        _board[oy + c[1]][ox + c[0]] = p.color;
      }
      _tray[idx] = null;
      _score += p.cells.length;
      _hintIdx = null;
    });
    Sfx.play('pop');
    Sfx.vibe();

    // find full lines
    final rows = <int>[];
    final cols = <int>[];
    for (int y = 0; y < n; y++) {
      if (_board[y].every((v) => v != 0)) rows.add(y);
    }
    for (int x = 0; x < n; x++) {
      bool full = true;
      for (int y = 0; y < n; y++) {
        if (_board[y][x] == 0) full = false;
      }
      if (full) cols.add(x);
    }
    final lines = rows.length + cols.length;

    if (lines > 0) {
      _busy = true;
      final cells = <int>{};
      for (final y in rows) {
        for (int x = 0; x < n; x++) cells.add(y * n + x);
      }
      for (final x in cols) {
        for (int y = 0; y < n; y++) cells.add(y * n + x);
      }
      final k = _combo;
      int pts;
      if (lines == 1) {
        pts = 10 * k;
      } else {
        pts = 10 * k * lines * (lines - 1);
      }
      setState(() => _clearing.addAll(cells));
      Sfx.play(lines >= 2 || k >= 3 ? 'combo' : 'clear');
      Sfx.vibe(true);
      // particles at center of cleared area
      final boardBox =
          _boardKey.currentContext?.findRenderObject() as RenderBox?;
      final bs = boardBox?.size.width ?? 320;
      for (final ci in cells) {
        if (_rnd.nextDouble() < 0.35) {
          _burst((ci % n + 0.5) * bs / n, (ci ~/ n + 0.5) * bs / n,
              _board[ci ~/ n][ci % n]);
        }
      }
      _combo++;
      _missStreak = 0;
      final label = _combo - 1;
      String word;
      if (lines >= 4) {
        word = 'Unbelievable!';
      } else if (lines == 3) {
        word = 'Excellent!';
      } else if (lines == 2) {
        word = 'Great!';
      } else if (label >= 3) {
        word = 'Amazing!';
      } else {
        word = 'Good!';
      }
      Future.delayed(const Duration(milliseconds: 300), () {
        if (!mounted) return;
        setState(() {
          for (final ci in cells) {
            _board[ci ~/ n][ci % n] = 0;
          }
          _clearing.clear();
          _score += pts;
          bool allClear = _board.every((r) => r.every((v) => v == 0));
          if (allClear && _dealCount >= 6) {
            _score += 300;
            word = 'Perfect! +300';
          }
          _praise = word;
          _praiseKey++;
          _busy = false;
        });
        final bs2 =
            (_boardKey.currentContext?.findRenderObject() as RenderBox?)
                    ?.size
                    .width ??
                320;
        _floats.add(_FloatText(bs2 / 2, bs2 / 2 - 20, '+$pts'));
        _startFx();
        _afterMove();
      });
    } else {
      _missStreak++;
      if (_missStreak >= 3) {
        _combo = 1;
        _missStreak = 0;
      }
      _afterMove();
    }
  }

  void _afterMove() {
    if (_score > _best) {
      _best = _score;
      Prefs.saveBest('block', _score);
    }
    if (_tray.every((p) => p == null)) {
      setState(_deal);
    }
    final remaining = _tray.whereType<Piece>().toList();
    if (remaining.isNotEmpty && remaining.every((p) => !_anyFit(p))) {
      _gameOver();
    }
    setState(() {});
  }

  Future<void> _gameOver() async {
    _over = true;
    Sfx.play('lose');
    if (!_reviveUsed && mounted) {
      final revive = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          backgroundColor: const Color(0xFF2B3A8F),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: const Text('No more moves!',
              textAlign: TextAlign.center,
              style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
          content: const Text(
              'Watch an ad to clear space and keep playing from here?',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70)),
          actionsAlignment: MainAxisAlignment.center,
          actions: [
            TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('No thanks',
                    style: TextStyle(color: Colors.white54))),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFF5B921)),
              onPressed: () => Navigator.of(context).pop(true),
              icon: const Icon(Icons.play_circle_fill, color: Colors.white),
              label: const Text('Revive',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w800)),
            ),
          ],
        ),
      );
      if (revive == true && mounted) {
        final ok = await showRewardedAd(context);
        if (ok && mounted) {
          _reviveUsed = true;
          _over = false;
          // clear the 3 fullest rows
          final counts = List.generate(
              n, (y) => _board[y].where((v) => v != 0).length);
          final idx = List.generate(n, (i) => i)
            ..sort((a, b) => counts[b] - counts[a]);
          setState(() {
            for (int i = 0; i < 3; i++) {
              _board[idx[i]] = List.filled(n, 0);
            }
          });
          Sfx.play('clear');
          return;
        }
      }
    }
    if (!mounted) return;
    showAdBreak(context);
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF2B3A8F),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('Game Over',
            textAlign: TextAlign.center,
            style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 26)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('SCORE',
                style: TextStyle(color: Colors.white54, letterSpacing: 2)),
            Text('$_score',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 44,
                    fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text('Best  $_best',
                style: const TextStyle(
                    color: Color(0xFFF5B921),
                    fontSize: 19,
                    fontWeight: FontWeight.w800)),
          ],
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
              },
              child: const Text('Home',
                  style: TextStyle(color: Colors.white54))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF35C759),
                padding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16))),
            onPressed: () {
              Navigator.of(context).pop();
              _restart();
            },
            child: const Text('Play Again',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  void _restart() {
    setState(() {
      _board = List.generate(n, (_) => List.filled(n, 0));
      _score = 0;
      _combo = 1;
      _missStreak = 0;
      _dealCount = 0;
      _reviveUsed = false;
      _over = false;
      _deal();
    });
  }

  Future<void> _useHint() async {
    final ok = await HintBank.useHint(context);
    if (!ok || !mounted) return;
    // find best placement: prefer one that clears lines
    int? bx, by, bIdx;
    int bestGain = -1;
    for (int i = 0; i < 3; i++) {
      final p = _tray[i];
      if (p == null) continue;
      for (int y = 0; y < n; y++) {
        for (int x = 0; x < n; x++) {
          if (!_fits(p, x, y)) continue;
          int gain = 0;
          final copy = _board.map((r) => List<int>.from(r)).toList();
          for (final c in p.cells) {
            copy[y + c[1]][x + c[0]] = p.color;
          }
          for (int yy = 0; yy < n; yy++) {
            if (copy[yy].every((v) => v != 0)) gain += 10;
          }
          for (int xx = 0; xx < n; xx++) {
            bool full = true;
            for (int yy = 0; yy < n; yy++) {
              if (copy[yy][xx] == 0) full = false;
            }
            if (full) gain += 10;
          }
          if (gain > bestGain) {
            bestGain = gain;
            bx = x;
            by = y;
            bIdx = i;
          }
        }
      }
    }
    if (bIdx != null) {
      setState(() {
        _hintIdx = bIdx;
        _hintX = bx;
        _hintY = by;
      });
      Sfx.play('blip');
    }
  }

  // ---- drag handling -------------------------------------------------------
  void _updateTarget() {
    final box = _boardKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null || _dragIdx == null) return;
    final origin = box.localToGlobal(Offset.zero);
    final p = _tray[_dragIdx!]!;
    // piece floats above the finger by ~1.3 cells
    final fx = _dragPos.dx - origin.dx - (p.w * _cell) / 2;
    final fy = _dragPos.dy - origin.dy - (p.h * _cell) / 2 - _cell * 1.3;
    final tx = (fx / _cell).round();
    final ty = (fy / _cell).round();
    setState(() {
      if (_fits(p, tx, ty)) {
        _targetX = tx;
        _targetY = ty;
      } else {
        _targetX = null;
        _targetY = null;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF4A5FC1), Color(0xFF2B3A8F), Color(0xFF1E2A6B)],
          ),
        ),
        child: Stack(
          key: _rootKey,
          children: [
            SafeArea(
              child: LayoutBuilder(builder: (context, cons) {
            final boardSize = min(cons.maxWidth - 28, cons.maxHeight * 0.52);
            _cell = boardSize / n;
            return Column(
              children: [
                // top bar: crown+best ... gear
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 8, 0),
                  child: Row(
                    children: [
                      const Text('👑', style: TextStyle(fontSize: 24)),
                      const SizedBox(width: 4),
                      Text('$_best',
                          style: const TextStyle(
                              color: Color(0xFFF5B921),
                              fontSize: 22,
                              fontWeight: FontWeight.w900)),
                      const Spacer(),
                      HintButton(onHint: _useHint),
                      const SizedBox(width: 8),
                      IconButton(
                        icon: const Icon(Icons.settings,
                            color: Colors.white70, size: 28),
                        onPressed: () {
                          Sfx.play('click');
                          _showSettings(context, _restart);
                        },
                      ),
                    ],
                  ),
                ),
                Text('$_score',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 54,
                        fontWeight: FontWeight.w900)),
                if (_combo - 1 >= 2)
                  Text('Combo x${_combo - 1}',
                      style: const TextStyle(
                          color: Color(0xFFFFD93B),
                          fontSize: 17,
                          fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                // board + overlays
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      key: _boardKey,
                      width: boardSize,
                      height: boardSize,
                      decoration: BoxDecoration(
                        color: const Color(0xFF1B2452),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: Colors.white.withOpacity(0.15), width: 2),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: CustomPaint(
                          painter: _BoardPainter(
                            board: _board,
                            clearing: _clearing,
                            target: (_dragIdx != null && _targetX != null)
                                ? [ _targetX!, _targetY! ]
                                : null,
                            targetPiece:
                                _dragIdx != null ? _tray[_dragIdx!] : null,
                            hint: (_hintIdx != null)
                                ? [_hintX!, _hintY!]
                                : null,
                            hintPiece:
                                _hintIdx != null ? _tray[_hintIdx!] : null,
                            particles: _particles,
                            floats: _floats,
                          ),
                          size: Size(boardSize, boardSize),
                        ),
                      ),
                    ),
                    Positioned.fill(child: PraiseWord(word: _praise, showKey: _praiseKey)),
                  ],
                ),
                const SizedBox(height: 18),
                // tray
                SizedBox(
                  height: _cell * 3.4,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      for (int i = 0; i < 3; i++) _traySlot(i),
                    ],
                  ),
                ),
                const Spacer(),
              ],
            );
              }),
            ),
            if (_dragIdx != null && _tray[_dragIdx!] != null)
              _floatingPiece(),
          ],
        ),
      ),
    );
  }

  Widget _floatingPiece() {
    final p = _tray[_dragIdx!]!;
    final box = _rootKey.currentContext?.findRenderObject() as RenderBox?;
    Offset local = _dragPos;
    if (box != null) {
      local = box.globalToLocal(_dragPos);
    }
    return Positioned(
      left: local.dx - (p.w * _cell) / 2,
      top: local.dy - (p.h * _cell) / 2 - _cell * 1.3,
      child: IgnorePointer(
        child: PieceView(cells: p.cells, color: p.color, cell: _cell),
      ),
    );
  }

  Widget _traySlot(int i) {
    final p = _tray[i];
    if (p == null) return SizedBox(width: _cell * 3, height: _cell * 3);
    final cellTray = _cell * 0.92;
    final view = PieceView(cells: p.cells, color: p.color, cell: cellTray);
    if (_dragIdx == i) {
      // while dragging, show faint placeholder + floating piece follows finger
      return SizedBox(
        width: _cell * 3,
        height: _cell * 3,
        child: Opacity(opacity: 0.25, child: view),
      );
    }
    return GestureDetector(
      onPanStart: _busy || _over
          ? null
          : (d) {
              setState(() {
                _dragIdx = i;
                _dragPos = d.globalPosition;
                _hintIdx = null;
              });
              Sfx.play('click');
              _updateTarget();
            },
      onPanUpdate: _busy || _over
          ? null
          : (d) {
              setState(() => _dragPos = d.globalPosition);
              _updateTarget();
            },
      onPanEnd: _busy || _over
          ? null
          : (d) {
              final idx = _dragIdx;
              final tx = _targetX, ty = _targetY;
              setState(() {
                _dragIdx = null;
                _targetX = null;
                _targetY = null;
              });
              if (idx != null && tx != null && ty != null) {
                _place(idx, tx, ty);
              }
            },
      child: SizedBox(width: _cell * 3, height: _cell * 3, child: view),
    );
  }
}

void _showSettings(BuildContext context, VoidCallback onReplay) {
  showDialog(
    context: context,
    builder: (_) => StatefulBuilder(builder: (context, setD) {
      return AlertDialog(
        backgroundColor: const Color(0xFF2B3A8F),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('Settings',
            textAlign: TextAlign.center,
            style:
                TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SwitchListTile(
              title:
                  const Text('Sound', style: TextStyle(color: Colors.white)),
              value: Sfx.soundOn,
              onChanged: (v) {
                Sfx.soundOn = v;
                Prefs.setBool('set_sound', v);
                setD(() {});
              },
            ),
            SwitchListTile(
              title:
                  const Text('Music', style: TextStyle(color: Colors.white)),
              value: Sfx.bgmOn,
              onChanged: (v) {
                Sfx.bgmOn = v;
                Prefs.setBool('set_bgm', v);
                Sfx.applyBgm();
                setD(() {});
              },
            ),
            SwitchListTile(
              title: const Text('Vibration',
                  style: TextStyle(color: Colors.white)),
              value: Sfx.vibeOn,
              onChanged: (v) {
                Sfx.vibeOn = v;
                Prefs.setBool('set_vibe', v);
                setD(() {});
              },
            ),
            const SizedBox(height: 8),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF35C759)),
              onPressed: () {
                Navigator.of(context).pop();
                onReplay();
              },
              icon: const Icon(Icons.replay, color: Colors.white),
              label: const Text('Replay',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w800)),
            ),
          ],
        ),
      );
    }),
  );
}

// ---------------------------------------------------------------------------
class _BoardPainter extends CustomPainter {
  _BoardPainter({
    required this.board,
    required this.clearing,
    required this.target,
    required this.targetPiece,
    required this.hint,
    required this.hintPiece,
    required this.particles,
    required this.floats,
  });
  final List<List<int>> board;
  final Set<int> clearing;
  final List<int>? target;
  final Piece? targetPiece;
  final List<int>? hint;
  final Piece? hintPiece;
  final List<_Particle> particles;
  final List<_FloatText> floats;

  @override
  void paint(Canvas canvas, Size size) {
    final n = 8;
    final cell = size.width / n;
    final bgPaint = Paint()..color = const Color(0xFF232C5E);
    final gapPaint = Paint()..color = const Color(0xFF1B2452);
    // empty cells
    for (int y = 0; y < n; y++) {
      for (int x = 0; x < n; x++) {
        final r = Rect.fromLTWH(
            x * cell + 1.5, y * cell + 1.5, cell - 3, cell - 3);
        canvas.drawRRect(
            RRect.fromRectAndRadius(r, Radius.circular(cell * 0.16)),
            board[y][x] == 0 ? bgPaint : gapPaint);
      }
    }
    // ghost target
    void drawCells(Piece p, int ox, int oy, bool ghost) {
      for (final c in p.cells) {
        final x = ox + c[0], y = oy + c[1];
        _drawBlock(canvas, x * cell, y * cell, cell, kBlockBase[p.color],
            ghost ? 0.45 : 1.0);
      }
    }

    if (hint != null && hintPiece != null) {
      for (final c in hintPiece!.cells) {
        final x = hint![0] + c[0], y = hint![1] + c[1];
        final r = Rect.fromLTWH(
            x * cell + 1.5, y * cell + 1.5, cell - 3, cell - 3);
        canvas.drawRRect(
            RRect.fromRectAndRadius(r, Radius.circular(cell * 0.16)),
            Paint()
              ..color = Colors.white.withOpacity(0.5)
              ..style = PaintingStyle.stroke
              ..strokeWidth = 3);
      }
    }
    if (target != null && targetPiece != null) {
      drawCells(targetPiece!, target![0], target![1], true);
    }
    // placed blocks
    for (int y = 0; y < n; y++) {
      for (int x = 0; x < n; x++) {
        final v = board[y][x];
        if (v == 0) continue;
        final flashing = clearing.contains(y * n + x);
        _drawBlock(canvas, x * cell, y * cell, cell, kBlockBase[v],
            flashing ? 0.55 : 1.0);
      }
    }
    // particles
    for (final p in particles) {
      canvas.drawCircle(
          Offset(p.x, p.y),
          3.2 * p.life + 1,
          Paint()..color = p.color.withOpacity(p.life.clamp(0, 1)));
    }
    // floating +N
    for (final f in floats) {
      final tp = TextPainter(
        text: TextSpan(
          text: f.text,
          style: TextStyle(
            color: Colors.white.withOpacity(f.life.clamp(0, 1)),
            fontSize: 30,
            fontWeight: FontWeight.w900,
            shadows: const [Shadow(color: Colors.black54, blurRadius: 6)],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas,
          Offset(f.x - tp.width / 2, f.y - (1 - f.life) * 40 - tp.height / 2));
    }
  }

  void _drawBlock(
      Canvas canvas, double x, double y, double cell, Color base, double alpha) {
    final r = Rect.fromLTWH(x + 1.5, y + 1.5, cell - 3, cell - 3);
    final rr = RRect.fromRectAndRadius(r, Radius.circular(cell * 0.16));
    final grad = LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        lighten(base, 0.45).withOpacity(alpha),
        base.withOpacity(alpha),
        darken(base, 0.18).withOpacity(alpha)
      ],
      stops: const [0.0, 0.55, 1.0],
    );
    canvas.drawRRect(rr, Paint()..shader = grad.createShader(r));
    // gloss
    final gr = Rect.fromLTWH(
        x + cell * 0.12, y + cell * 0.09, cell * 0.76, cell * 0.34);
    canvas.drawRRect(
        RRect.fromRectAndRadius(gr, Radius.circular(cell * 0.14)),
        Paint()
          ..color = Colors.white.withOpacity(0.38 * alpha));
  }

  @override
  bool shouldRepaint(covariant _BoardPainter old) => true;
}
