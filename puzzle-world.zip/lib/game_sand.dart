import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'services.dart';
import 'common.dart';

// ===========================================================================
// SAND CRUSH: drop sand-block pieces; the sand pours and piles up.
// When one color connects the LEFT wall to the RIGHT wall, it clears!
// Reach the level target before the sand reaches the top.
// ===========================================================================

const List<Color> _sandColors = [
  Colors.transparent,
  Color(0xFFEF3E36), // red
  Color(0xFF2D7FF9), // blue
  Color(0xFFF5B921), // yellow
  Color(0xFF35C759), // green
  Color(0xFF8B46C7), // purple
  Color(0xFFF07D1A), // orange
];

const List<List<List<int>>> _sandShapes = [
  [[0, 0], [1, 0], [0, 1], [1, 1]], // square
  [[0, 0], [1, 0], [2, 0]], // bar 3
  [[0, 0], [1, 0], [2, 0], [3, 0]], // bar 4
  [[0, 0], [0, 1], [1, 1]], // corner
  [[0, 0], [1, 0], [1, 1]], // corner flip
  [[0, 0], [1, 0], [2, 0], [1, 1]], // T
  [[1, 0], [2, 0], [0, 1], [1, 1]], // S
  [[0, 0], [0, 1], [0, 2]], // vertical 3
  [[0, 0], [1, 0]], // domino
];

class _SandPiece {
  _SandPiece(this.cells, this.color);
  final List<List<int>> cells;
  final int color;
  int get w => cells.map((c) => c[0]).reduce(max) + 1;
}

class SandCrushGame extends StatefulWidget {
  const SandCrushGame({super.key});
  @override
  State<SandCrushGame> createState() => _SandCrushGameState();
}

class _SandCrushGameState extends State<SandCrushGame> {
  static const int cols = 54;
  static const int rows = 72;
  static const int grainPerCell = 4; // one shape cell = 4x4 grains
  final _rnd = Random();
  Uint8List _grid = Uint8List(cols * rows);
  List<_SandPiece?> _tray = [null, null, null];
  int _selected = 0;
  int _level = 1;
  int _score = 0;
  int _best = 0;
  bool _busy = false;
  bool _over = false;
  bool _reviveUsed = false;
  double _aimGX = cols / 2;
  int? _hintGX;
  String _praise = '';
  int _praiseKey = 0;

  int get _target => (300 * pow(1.5, _level - 1)).round();
  int get _colorCount => min(3 + (_level - 1), 6);

  @override
  void initState() {
    super.initState();
    _load();
    _deal();
    _physicsLoop();
  }

  Future<void> _load() async {
    _level = await Prefs.level('sand');
    _best = await Prefs.best('sand');
    if (mounted) setState(() {});
  }

  void _deal() {
    _tray = List.generate(3, (_) {
      final s = _sandShapes[_rnd.nextInt(_sandShapes.length)];
      return _SandPiece(s, 1 + _rnd.nextInt(_colorCount));
    });
    _selected = 0;
  }

  // ---- sand physics ---------------------------------------------------------
  int _stepGrid(Uint8List g) {
    int moved = 0;
    for (int y = rows - 2; y >= 0; y--) {
      // random horizontal scan direction for natural flow
      final ltr = _rnd.nextBool();
      for (int i = 0; i < cols; i++) {
        final x = ltr ? i : cols - 1 - i;
        final idx = y * cols + x;
        final v = g[idx];
        if (v == 0) continue;
        final below = idx + cols;
        if (g[below] == 0) {
          g[below] = v;
          g[idx] = 0;
          moved++;
          continue;
        }
        final firstLeft = _rnd.nextBool();
        for (int s = 0; s < 2; s++) {
          final dx = (s == 0) == firstLeft ? -1 : 1;
          final nx = x + dx;
          if (nx < 0 || nx >= cols) continue;
          final dIdx = below + dx;
          if (g[dIdx] == 0) {
            g[dIdx] = v;
            g[idx] = 0;
            moved++;
            break;
          }
        }
      }
    }
    return moved;
  }

  Future<void> _physicsLoop() async {
    int stillTicks = 0;
    while (mounted) {
      await Future.delayed(const Duration(milliseconds: 30));
      if (!mounted) return;
      if (_over) continue;
      final moved = _stepGrid(_grid);
      if (moved > 0) {
        stillTicks = 0;
        if (mounted) setState(() {});
      } else {
        stillTicks++;
        if (_busy && stillTicks >= 2) {
          _busy = false;
          await _resolve();
        }
      }
    }
  }

  Future<void> _resolve() async {
    // clear wall-to-wall connected colors (repeat after falls settle)
    bool clearedAny = false;
    while (mounted) {
      final regions = _findBridges(_grid);
      if (regions.isEmpty) break;
      int grains = 0;
      setState(() {
        for (final idx in regions) {
          _grid[idx] = 0;
          grains++;
        }
        _score += grains;
      });
      clearedAny = true;
      Sfx.play('clear');
      Sfx.vibe(true);
      if (grains >= 200) {
        _praise = 'Amazing!';
      } else if (grains >= 100) {
        _praise = 'Great!';
      } else {
        _praise = 'Good!';
      }
      setState(() => _praiseKey++);
      // let the sand above fall
      _busy = true;
      return; // physics loop will settle then call _resolve again
    }
    if (!clearedAny) {
      // check win / lose
      if (_score >= _target) {
        _levelComplete();
        return;
      }
      bool topped = false;
      for (int x = 0; x < cols; x++) {
        if (_grid[4 * cols + x] != 0) topped = true;
      }
      if (topped) {
        _gameOver();
        return;
      }
      if (_tray.every((p) => p == null)) {
        setState(_deal);
      }
    }
    if (mounted) setState(() {});
  }

  List<int> _findBridges(Uint8List g) {
    final visited = Uint8List(cols * rows);
    final result = <int>[];
    for (int y = 0; y < rows; y++) {
      final start = y * cols;
      final color = g[start];
      if (color == 0 || visited[start] == 1) continue;
      // flood fill from left wall
      final region = <int>[];
      final stack = [start];
      visited[start] = 1;
      bool touchesRight = false;
      while (stack.isNotEmpty) {
        final cur = stack.removeLast();
        region.add(cur);
        final cx = cur % cols;
        if (cx == cols - 1) touchesRight = true;
        const dirs = [1, -1, cols, -cols];
        for (final d in dirs) {
          final nb = cur + d;
          if (nb < 0 || nb >= cols * rows) continue;
          if (d == 1 && cx == cols - 1) continue;
          if (d == -1 && cx == 0) continue;
          if (visited[nb] == 1 || g[nb] != color) continue;
          visited[nb] = 1;
          stack.add(nb);
        }
      }
      if (touchesRight) result.addAll(region);
    }
    return result;
  }

  void _drop() {
    if (_busy || _over) return;
    final p = _tray[_selected];
    if (p == null) return;
    final pieceGrainsW = p.w * grainPerCell;
    int gx = (_aimGX - pieceGrainsW / 2).round().clamp(0, cols - pieceGrainsW);
    int placed = 0, blocked = 0;
    for (final c in p.cells) {
      for (int dy = 0; dy < grainPerCell; dy++) {
        for (int dx = 0; dx < grainPerCell; dx++) {
          final x = gx + c[0] * grainPerCell + dx;
          final y = c[1] * grainPerCell + dy;
          final idx = y * cols + x;
          if (_grid[idx] == 0) {
            _grid[idx] = p.color;
            placed++;
          } else {
            blocked++;
          }
        }
      }
    }
    if (placed == 0 || blocked > placed) {
      _gameOver();
      return;
    }
    setState(() {
      _tray[_selected] = null;
      _busy = true;
      _hintGX = null;
      // auto-select next available piece
      final next = _tray.indexWhere((e) => e != null);
      if (next >= 0) _selected = next;
    });
    Sfx.play('pop');
    Sfx.vibe();
  }

  void _levelComplete() {
    _over = true;
    Prefs.saveBest('sand', _score);
    Prefs.saveLevel('sand', _level + 1);
    showLevelComplete(context,
        title: 'Level $_level Complete! 🎉',
        message: 'Target $_target reached — Score: $_score',
        onNext: () {
          setState(() {
            _level++;
            _grid = Uint8List(cols * rows);
            _score = 0;
            _over = false;
            _reviveUsed = false;
            _deal();
          });
        },
        onReplay: () {
          setState(() {
            _grid = Uint8List(cols * rows);
            _score = 0;
            _over = false;
            _deal();
          });
        });
  }

  Future<void> _gameOver() async {
    if (_over) return;
    _over = true;
    Sfx.play('lose');
    Prefs.saveBest('sand', _score);
    if (!_reviveUsed && mounted) {
      final revive = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          backgroundColor: const Color(0xFF2B3A8F),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: const Text('Sand reached the top!',
              textAlign: TextAlign.center,
              style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
          content: const Text(
              'Watch an ad to clear the bottom of the box and keep playing?',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70)),
          actionsAlignment: MainAxisAlignment.center,
          actions: [
            TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('No thanks',
                    style: TextStyle(color: Colors.white54))),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFF5B921)),
              onPressed: () => Navigator.of(context).pop(true),
              icon: const Icon(Icons.play_circle_fill, color: Colors.white),
              label: const Text('Revive',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w800)),
            ),
          ],
        ),
      );
      if (revive == true && mounted) {
        final ok = await showRewardedAd(context);
        if (ok) {
          setState(() {
            _reviveUsed = true;
            _over = false;
            _busy = true;
            for (int y = (rows * 0.62).floor(); y < rows; y++) {
              for (int x = 0; x < cols; x++) {
                _grid[y * cols + x] = 0;
              }
            }
          });
          return;
        }
      }
    }
    if (!mounted) return;
    showAdBreak(context);
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF2B3A8F),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('Game Over',
            textAlign: TextAlign.center,
            style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 25)),
        content: Text('Score: $_score\nBest: $_best',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70, fontSize: 17)),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
              },
              child: const Text('Home',
                  style: TextStyle(color: Colors.white54))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF35C759)),
            onPressed: () {
              Navigator.of(context).pop();
              setState(() {
                _grid = Uint8List(cols * rows);
                _score = 0;
                _over = false;
                _reviveUsed = false;
                _deal();
              });
            },
            child: const Text('Play Again',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  Future<void> _hint() async {
    final ok = await HintBank.useHint(context);
    if (!ok || !mounted) return;
    final p = _tray[_selected];
    if (p == null) return;
    // simulate drops at sampled x positions, pick the one clearing the most
    int bestX = cols ~/ 2;
    int bestGain = -1;
    final pieceGrainsW = p.w * grainPerCell;
    for (int gx = 0; gx <= cols - pieceGrainsW; gx += 3) {
      final copy = Uint8List.fromList(_grid);
      for (final c in p.cells) {
        for (int dy = 0; dy < grainPerCell; dy++) {
          for (int dx = 0; dx < grainPerCell; dx++) {
            final x = gx + c[0] * grainPerCell + dx;
            final y = c[1] * grainPerCell + dy;
            if (copy[y * cols + x] == 0) copy[y * cols + x] = p.color;
          }
        }
      }
      int guard = 0;
      while (_stepGrid(copy) > 0 && guard++ < 300) {}
      final gain = _findBridges(copy).length;
      if (gain > bestGain) {
        bestGain = gain;
        bestX = gx + pieceGrainsW ~/ 2;
      }
    }
    setState(() => _hintGX = bestX);
    Sfx.play('blip');
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(bestGain > 0
          ? 'Hint: drop at the green line to clear $bestGain sand!'
          : 'Hint: drop at the green line'),
      duration: const Duration(seconds: 2),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF4A5FC1), Color(0xFF2B3A8F)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 8, 0),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back_ios_new,
                          color: Colors.white, size: 22),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                    const Text('👑', style: TextStyle(fontSize: 21)),
                    const SizedBox(width: 4),
                    Text('$_best',
                        style: const TextStyle(
                            color: Color(0xFFF5B921),
                            fontSize: 20,
                            fontWeight: FontWeight.w900)),
                    const Spacer(),
                    Text('Level $_level',
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 17)),
                    const Spacer(),
                    HintButton(onHint: _hint),
                    const SizedBox(width: 10),
                  ],
                ),
              ),
              // progress bar  score -> target
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 4, 18, 6),
                child: Row(
                  children: [
                    const Text('0',
                        style: TextStyle(
                            color: Colors.white70,
                            fontWeight: FontWeight.w800)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: LinearProgressIndicator(
                          value: (_score / _target).clamp(0, 1),
                          minHeight: 16,
                          backgroundColor: const Color(0xFF1B2452),
                          valueColor: const AlwaysStoppedAnimation(
                              Color(0xFF35A7E0)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text('$_score / $_target',
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800)),
                  ],
                ),
              ),
              Expanded(
                child: Center(
                  child: LayoutBuilder(builder: (context, cons) {
                    final bw = min(cons.maxWidth - 24, (cons.maxHeight) * cols / rows);
                    final bh = bw * rows / cols;
                    return GestureDetector(
                      onPanStart: (d) {
                        setState(() => _aimGX =
                            (d.localPosition.dx / bw * cols).clamp(0, cols - 1));
                      },
                      onPanUpdate: (d) {
                        setState(() => _aimGX =
                            (d.localPosition.dx / bw * cols).clamp(0, cols - 1));
                      },
                      onPanEnd: (_) => _drop(),
                      onTapUp: (d) {
                        setState(() => _aimGX =
                            (d.localPosition.dx / bw * cols).clamp(0, cols - 1));
                        _drop();
                      },
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Container(
                            width: bw,
                            height: bh,
                            decoration: BoxDecoration(
                              color: const Color(0xFF101736),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.white.withOpacity(0.2),
                                  width: 2),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: CustomPaint(
                                painter: _SandPainter(
                                  grid: _grid,
                                  aimGX: _aimGX,
                                  piece: _tray[_selected],
                                  hintGX: _hintGX,
                                ),
                                size: Size(bw, bh),
                              ),
                            ),
                          ),
                          Positioned.fill(
                              child:
                                  PraiseWord(word: _praise, showKey: _praiseKey)),
                        ],
                      ),
                    );
                  }),
                ),
              ),
              // tray
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    for (int i = 0; i < 3; i++)
                      GestureDetector(
                        onTap: () {
                          if (_tray[i] != null) {
                            setState(() => _selected = i);
                            Sfx.play('click');
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: _selected == i && _tray[i] != null
                                ? Colors.white.withOpacity(0.22)
                                : Colors.transparent,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: _tray[i] == null
                              ? const SizedBox(width: 56, height: 44)
                              : PieceView(
                                  cells: _tray[i]!.cells,
                                  color: _tray[i]!.color,
                                  cell: 15),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SandPainter extends CustomPainter {
  _SandPainter(
      {required this.grid,
      required this.aimGX,
      required this.piece,
      required this.hintGX});
  final Uint8List grid;
  final double aimGX;
  final _SandPiece? piece;
  final int? hintGX;

  @override
  void paint(Canvas canvas, Size size) {
    const cols = _SandCrushGameState.cols;
    const rows = _SandCrushGameState.rows;
    final cw = size.width / cols;
    final ch = size.height / rows;
    // danger line
    canvas.drawLine(
        Offset(0, 8 * ch),
        Offset(size.width, 8 * ch),
        Paint()
          ..color = Colors.red.withOpacity(0.6)
          ..strokeWidth = 2);
    // grains (row runs)
    for (int y = 0; y < rows; y++) {
      int x = 0;
      while (x < cols) {
        final v = grid[y * cols + x];
        if (v == 0) {
          x++;
          continue;
        }
        int x2 = x;
        while (x2 + 1 < cols && grid[y * cols + x2 + 1] == v) {
          x2++;
        }
        canvas.drawRect(
          Rect.fromLTWH(x * cw, y * ch, (x2 - x + 1) * cw + 0.5, ch + 0.5),
          Paint()..color = _sandColors[v],
        );
        x = x2 + 1;
      }
    }
    // hint line
    if (hintGX != null) {
      canvas.drawLine(
          Offset(hintGX! * cw, 0),
          Offset(hintGX! * cw, size.height),
          Paint()
            ..color = const Color(0xFF35C759)
            ..strokeWidth = 3);
    }
    // ghost piece at top
    if (piece != null) {
      final gw = piece!.w * _SandCrushGameState.grainPerCell;
      final gx = (aimGX - gw / 2).clamp(0, cols - gw).toDouble();
      for (final c in piece!.cells) {
        for (int dy = 0; dy < _SandCrushGameState.grainPerCell; dy++) {
          for (int dx = 0; dx < _SandCrushGameState.grainPerCell; dx++) {
            final x = gx + c[0] * _SandCrushGameState.grainPerCell + dx;
            final y = c[1] * _SandCrushGameState.grainPerCell + dy;
            canvas.drawRect(
              Rect.fromLTWH(x * cw, y * ch, cw + 0.5, ch + 0.5),
              Paint()..color = _sandColors[piece!.color].withOpacity(0.55),
            );
          }
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant _SandPainter old) => true;
}
