import 'dart:math';
import 'package:flutter/material.dart';
import 'services.dart';
import 'common.dart';

// ===========================================================================
// WATER SORT: pour colors between tubes until each tube is one color.
// Levels generated from the solved state by random legal pours = solvable.
// Colors grow with level (difficulty ramp).
// ===========================================================================

const List<Color> _tubeColors = [
  Color(0xFFEF3E36), Color(0xFFF5B921), Color(0xFF35C759), Color(0xFF2D7FF9),
  Color(0xFFF07D1A), Color(0xFF8B46C7), Color(0xFF17B6CF), Color(0xFFF0568B),
  Color(0xFF795548), Color(0xFF607D8B),
];

class WaterSortGame extends StatefulWidget {
  const WaterSortGame({super.key});
  @override
  State<WaterSortGame> createState() => _WaterSortGameState();
}

class _WaterSortGameState extends State<WaterSortGame> {
  static const int cap = 4;
  final _rnd = Random();
  int _level = 1;
  List<List<int>> _tubes = [];
  List<List<List<int>>> _history = [];
  int? _selected;
  bool _won = false;
  bool _extraUsed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    _level = await Prefs.level('water');
    _gen(_level);
  }

  int _colorsFor(int lv) => min(3 + (lv - 1), 9); // 3,4,5,...9

  void _gen(int lv) {
    final k = _colorsFor(lv);
    // solved state: k full tubes + 2 empty
    List<List<int>> t = [];
    for (int c = 0; c < k; c++) {
      t.add(List.filled(cap, c));
    }
    t.add([]);
    t.add([]);
    // scramble with random legal pours (reverse = solution)
    final moves = 30 + lv * 12;
    for (int i = 0; i < moves; i++) {
      final froms = <int>[], tos = <int>[];
      for (int a = 0; a < t.length; a++) {
        if (t[a].isEmpty) continue;
        for (int b = 0; b < t.length; b++) {
          if (a == b || t[b].length >= cap) continue;
          if (t[b].isEmpty || t[b].last == t[a].last) {
            froms.add(a);
            tos.add(b);
          }
        }
      }
      if (froms.isEmpty) break;
      final j = _rnd.nextInt(froms.length);
      _pourRaw(t, froms[j], tos[j]);
    }
    setState(() {
      _tubes = t;
      _history = [];
      _selected = null;
      _won = false;
      _extraUsed = false;
    });
  }

  void _pourRaw(List<List<int>> t, int from, int to) {
    if (t[from].isEmpty || t[to].length >= cap) return;
    final color = t[from].last;
    if (t[to].isNotEmpty && t[to].last != color) return;
    int run = 0;
    for (int i = t[from].length - 1; i >= 0 && t[from][i] == color; i--) {
      run++;
    }
    final amount = min(run, cap - t[to].length);
    for (int i = 0; i < amount; i++) {
      t[to].add(t[from].removeLast());
    }
  }

  bool get _isWon =>
      _tubes.every((t) => t.isEmpty || (t.length == cap && t.every((c) => c == t[0])));

  void _tap(int i) {
    if (_won) return;
    if (_selected == null) {
      if (_tubes[i].isEmpty) return;
      setState(() => _selected = i);
      Sfx.play('click');
      return;
    }
    if (_selected == i) {
      setState(() => _selected = null);
      return;
    }
    final from = _selected!;
    final before = _tubes.map((t) => List<int>.from(t)).toList();
    final copy = _tubes.map((t) => List<int>.from(t)).toList();
    _pourRaw(copy, from, i);
    if (copy.toString() != before.toString()) {
      _history.add(before);
      setState(() {
        _tubes = copy;
        _selected = null;
      });
      Sfx.play('pour');
      Sfx.vibe();
      if (_isWon) {
        _won = true;
        Prefs.saveLevel('water', _level + 1);
        Future.delayed(const Duration(milliseconds: 350), () {
          if (!mounted) return;
          showLevelComplete(context,
              title: 'Level $_level Complete! 🎉',
              message: 'All colors sorted!',
              onNext: () {
                setState(() => _level++);
                _gen(_level);
              },
              onReplay: () => _gen(_level));
        });
      }
    } else {
      setState(() => _selected = i);
    }
  }

  void _undo() {
    if (_history.isEmpty) return;
    setState(() {
      _tubes = _history.removeLast();
      _selected = null;
      _won = false;
    });
    Sfx.play('click');
  }

  Future<void> _hint() async {
    final ok = await HintBank.useHint(context);
    if (!ok || !mounted) return;
    // find a pour that finishes a tube or frees one, else any legal pour
    int? bf, bt;
    int bestScore = -1;
    for (int a = 0; a < _tubes.length; a++) {
      if (_tubes[a].isEmpty) continue;
      for (int b = 0; b < _tubes.length; b++) {
        if (a == b) continue;
        final copy = _tubes.map((t) => List<int>.from(t)).toList();
        final before = copy.toString();
        _pourRaw(copy, a, b);
        if (copy.toString() == before) continue;
        int s = 1;
        if (copy[b].length == cap && copy[b].every((c) => c == copy[b][0])) {
          s = 10;
        } else if (copy[a].isEmpty) {
          s = 6;
        } else if (_tubes[b].isEmpty) {
          s = 2;
        }
        if (s > bestScore) {
          bestScore = s;
          bf = a;
          bt = b;
        }
      }
    }
    if (bf != null) {
      setState(() => _selected = bf);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Hint: pour tube ${bf! + 1} into tube ${bt! + 1}'),
        duration: const Duration(seconds: 2),
      ));
      Sfx.play('blip');
    }
  }

  Future<void> _extraTube() async {
    if (_extraUsed) return;
    final ok = await showRewardedAd(context);
    if (ok && mounted) {
      setState(() {
        _tubes.add([]);
        _extraUsed = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF232347), Color(0xFF14142B)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              GameHeader(
                title: 'Level $_level',
                trailing: HintButton(onHint: _hint),
              ),
              const SizedBox(height: 10),
              Expanded(
                child: LayoutBuilder(builder: (context, cons) {
                  final perRow = _tubes.length <= 5 ? _tubes.length : (_tubes.length / 2).ceil();
                  final rows = <List<int>>[];
                  for (int i = 0; i < _tubes.length; i += perRow) {
                    rows.add(List.generate(
                        min(perRow, _tubes.length - i), (j) => i + j));
                  }
                  return Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      for (final row in rows)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              for (final i in row) _tubeWidget(i, cons.maxHeight),
                            ],
                          ),
                        ),
                    ],
                  );
                }),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 22),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _btn(Icons.undo, 'Undo', _undo),
                    _btn(Icons.add_box, _extraUsed ? 'Tube +' : 'Tube (Ad)',
                        _extraUsed ? null : _extraTube),
                    _btn(Icons.replay, 'Restart', () => _gen(_level)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _btn(IconData icon, String label, VoidCallback? onTap) {
    return Material(
      color: const Color(0xFF6C5CE7),
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap == null
            ? null
            : () {
                Sfx.play('click');
                onTap();
              },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(children: [
            Icon(icon, color: Colors.white, size: 22),
            const SizedBox(width: 6),
            Text(label,
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w700)),
          ]),
        ),
      ),
    );
  }

  Widget _tubeWidget(int i, double availH) {
    final tube = _tubes[i];
    final h = min(190.0, availH * 0.36);
    final segH = h / cap;
    final selected = _selected == i;
    return GestureDetector(
      onTap: () => _tap(i),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        transform: Matrix4.translationValues(0, selected ? -14 : 0, 0),
        width: 54,
        height: h + 6,
        decoration: BoxDecoration(
          border: Border.all(
              color: selected ? Colors.white : Colors.white54,
              width: selected ? 3 : 2),
          borderRadius: const BorderRadius.vertical(
              bottom: Radius.circular(26), top: Radius.circular(6)),
          color: Colors.white.withOpacity(0.06),
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(
              bottom: Radius.circular(24), top: Radius.circular(4)),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              for (int s = cap - 1; s >= 0; s--)
                Container(
                  height: segH - 1,
                  width: double.infinity,
                  color: s < tube.length
                      ? _tubeColors[tube[s]]
                      : Colors.transparent,
                ),
            ],
          ),
        ),
      ),
    );
  }
}
