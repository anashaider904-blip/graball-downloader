import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:audioplayers/audioplayers.dart';

const String kAdLink = 'https://uplcm.com/4/12269238';

// ---------------------------------------------------------------------------
// Persistent storage: best scores, levels, settings, hint bank
// ---------------------------------------------------------------------------
class Prefs {
  static SharedPreferences? _sp;
  static Future<SharedPreferences> get _i async =>
      _sp ??= await SharedPreferences.getInstance();

  static Future<int> getInt(String k, [int d = 0]) async =>
      (await _i).getInt(k) ?? d;
  static Future<void> setInt(String k, int v) async =>
      (await _i).setInt(k, v);
  static Future<bool> getBool(String k, [bool d = true]) async =>
      (await _i).getBool(k) ?? d;
  static Future<void> setBool(String k, bool v) async =>
      (await _i).setBool(k, v);

  static Future<int> best(String game) => getInt('best_$game');
  static Future<void> saveBest(String game, int v) async {
    final b = await best(game);
    if (v > b) await setInt('best_$game', v);
  }

  static Future<int> level(String game) => getInt('level_$game', 1);
  static Future<void> saveLevel(String game, int v) =>
      setInt('level_$game', v);
}

// ---------------------------------------------------------------------------
// Sound effects + background music (our own generated sounds)
// ---------------------------------------------------------------------------
class Sfx {
  static bool soundOn = true;
  static bool bgmOn = true;
  static bool vibeOn = true;
  static final AudioPlayer _p = AudioPlayer();
  static final AudioPlayer _bgm = AudioPlayer();
  static bool _bgmStarted = false;

  static Future<void> loadSettings() async {
    soundOn = await Prefs.getBool('set_sound', true);
    bgmOn = await Prefs.getBool('set_bgm', true);
    vibeOn = await Prefs.getBool('set_vibe', true);
  }

  static void play(String name) {
    if (!soundOn) return;
    try {
      _p.stop();
      _p.play(AssetSource('sfx/$name.wav'));
    } catch (_) {}
  }

  static void startBgm() {
    if (_bgmStarted) return;
    _bgmStarted = true;
    try {
      _bgm.setReleaseMode(ReleaseMode.loop);
      _bgm.setVolume(0.35);
      if (bgmOn) _bgm.play(AssetSource('sfx/bgm.wav'));
    } catch (_) {}
  }

  static void applyBgm() {
    try {
      if (bgmOn) {
        _bgm.resume();
      } else {
        _bgm.pause();
      }
    } catch (_) {}
  }

  static void vibe([bool heavy = false]) {
    if (!vibeOn) return;
    try {
      if (heavy) {
        HapticFeedback.mediumImpact();
      } else {
        HapticFeedback.lightImpact();
      }
    } catch (_) {}
  }
}

// ---------------------------------------------------------------------------
// Monetag web ads (NO ads SDK). Rewarded: close unlocks after 10s.
// ---------------------------------------------------------------------------
DateTime? _lastAdShown;

Future<void> showAdBreak(BuildContext context) async {
  final now = DateTime.now();
  if (_lastAdShown != null && now.difference(_lastAdShown!).inSeconds < 60) {
    return;
  }
  _lastAdShown = now;
  await Navigator.of(context).push(
    MaterialPageRoute(
        builder: (_) => const AdBreakPage(rewarded: false),
        fullscreenDialog: true),
  );
}

Future<bool> showRewardedAd(BuildContext context) async {
  _lastAdShown = DateTime.now();
  final result = await Navigator.of(context).push<bool>(
    MaterialPageRoute(
        builder: (_) => const AdBreakPage(rewarded: true),
        fullscreenDialog: true),
  );
  return result == true;
}

class AdBreakPage extends StatefulWidget {
  const AdBreakPage({super.key, this.rewarded = false});
  final bool rewarded;
  @override
  State<AdBreakPage> createState() => _AdBreakPageState();
}

class _AdBreakPageState extends State<AdBreakPage> {
  WebViewController? _controller;
  Timer? _autoClose;
  Timer? _enableClose;
  bool _canClose = false;

  @override
  void initState() {
    super.initState();
    try {
      _controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..loadRequest(Uri.parse(kAdLink));
    } catch (_) {
      _controller = null;
    }
    _enableClose = Timer(Duration(seconds: widget.rewarded ? 10 : 5), () {
      if (mounted) setState(() => _canClose = true);
    });
    _autoClose = Timer(const Duration(seconds: 30), () {
      if (mounted) Navigator.of(context).pop(widget.rewarded ? true : null);
    });
  }

  @override
  void dispose() {
    _autoClose?.cancel();
    _enableClose?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        automaticallyImplyLeading: false,
        title: Text(widget.rewarded ? 'Watch ad to earn reward' : 'Ad',
            style: const TextStyle(fontSize: 15)),
        actions: [
          IconButton(
            icon: Icon(Icons.close,
                color: _canClose ? Colors.white : Colors.white24),
            onPressed: _canClose
                ? () => Navigator.of(context).pop(widget.rewarded)
                : null,
          ),
        ],
      ),
      body: _controller == null
          ? const Center(
              child: Text('Ad unavailable',
                  style: TextStyle(color: Colors.white54)))
          : WebViewWidget(controller: _controller!),
    );
  }
}

// ---------------------------------------------------------------------------
// Hint bank: first 3 hints FREE (ever), after that each hint = one rewarded ad
// ---------------------------------------------------------------------------
class HintBank {
  static const int freeTotal = 3;

  static Future<int> freeLeft() async {
    final used = await Prefs.getInt('free_hints_used');
    final left = freeTotal - used;
    return left < 0 ? 0 : left;
  }

  /// Returns true if a hint may be given (free hint consumed or ad watched).
  static Future<bool> useHint(BuildContext context) async {
    final left = await freeLeft();
    if (left > 0) {
      final used = await Prefs.getInt('free_hints_used');
      await Prefs.setInt('free_hints_used', used + 1);
      return true;
    }
    if (!context.mounted) return false;
    return showRewardedAd(context);
  }
}
