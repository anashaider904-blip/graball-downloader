import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';

// ---------------------------------------------------------------------------
// Puzzle World — 10 puzzle games in one app.
// Ads: Monetag Direct Link in a web view (no native ads SDK — Google's ads
// SDK stopped our other app from opening on some phones, so we never ship
// a native ads SDK again).
// ---------------------------------------------------------------------------
const String kAdLink = 'https://uplcm.com/4/12269238';

void main() {
  runApp(const PuzzleWorldApp());
}

// ---------------------------------------------------------------------------
// Ad break — shown when a game ends. Never blocks the player for long:
// close after 5s, auto-close at 30s, and any failure just closes.
// ---------------------------------------------------------------------------
DateTime _lastAdShown = DateTime.fromMillisecondsSinceEpoch(0);

Future<void> showAdBreak(BuildContext context) async {
  final now = DateTime.now();
  if (now.difference(_lastAdShown) < const Duration(seconds: 60)) return;
  _lastAdShown = now;
  await Navigator.of(context).push(
    MaterialPageRoute(builder: (_) => const AdBreakPage(), fullscreenDialog: true),
  );
}

/// Rewarded ad (Anas's design): the player CHOOSES to watch an ad to earn a
/// heart, a hint, or a revive that continues the same run. Returns true only
/// if the ad page stayed open long enough (the close button unlocks after
/// 10 seconds) — closing early earns nothing.
Future<bool> showRewardedAd(BuildContext context) async {
  _lastAdShown = DateTime.now();
  final result = await Navigator.of(context).push<bool>(
    MaterialPageRoute(
        builder: (_) => const AdBreakPage(rewarded: true), fullscreenDialog: true),
  );
  return result == true;
}

class AdBreakPage extends StatefulWidget {
  const AdBreakPage({super.key, this.rewarded = false});
  final bool rewarded;
  @override
  State<AdBreakPage> createState() => _AdBreakPageState();
}

class _AdBreakPageState extends State<AdBreakPage> {
  WebViewController? _controller;
  Timer? _autoClose;
  Timer? _enableClose;
  bool _canClose = false;

  @override
  void initState() {
    super.initState();
    try {
      _controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..loadRequest(Uri.parse(kAdLink));
    } catch (_) {
      _controller = null;
    }
    _enableClose = Timer(Duration(seconds: widget.rewarded ? 10 : 5), () {
      if (mounted) setState(() => _canClose = true);
    });
    _autoClose = Timer(const Duration(seconds: 30), () {
      if (mounted) Navigator.of(context).pop(widget.rewarded ? true : null);
    });
  }

  @override
  void dispose() {
    _autoClose?.cancel();
    _enableClose?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.rewarded
            ? 'Watch the ad — earn your reward!'
            : 'Ad — thanks for playing!'),
        leading: IconButton(
          icon: Icon(_canClose ? Icons.close : Icons.hourglass_top),
          onPressed: _canClose
              ? () => Navigator.of(context).pop(widget.rewarded ? true : null)
              : null,
        ),
      ),
      body: _controller == null
          ? const Center(child: Text('Ad could not load. Tap back to continue.'))
          : WebViewWidget(controller: _controller!),
    );
  }
}

// ---------------------------------------------------------------------------
// App + hub
// ---------------------------------------------------------------------------
class PuzzleWorldApp extends StatelessWidget {
  const PuzzleWorldApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Puzzle World',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7C3AED),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HubPage(),
    );
  }
}

class GameEntry {
  final String name;
  final String tagline;
  final IconData icon;
  final Color color;
  final String bestKey;
  final Widget Function()? page;
  const GameEntry(this.name, this.tagline, this.icon, this.color, this.bestKey, this.page);
}

final List<GameEntry> kGames = [
  GameEntry('Candy Match', 'Match 3 candies — sweet combos!', Icons.catching_pokemon,
      const Color(0xFFEC4899), 'best_candy', () => const CandyMatchPage()),
  GameEntry('2048', 'Slide & merge to reach 2048', Icons.grid_on,
      const Color(0xFFF59E0B), 'best_2048', () => const Game2048Page()),
  GameEntry('Block Puzzle', 'Fit blocks, clear lines', Icons.view_module,
      const Color(0xFF10B981), 'best_block', () => const BlockPuzzlePage()),
  const GameEntry('Ball Sort', 'Sort the coloured balls', Icons.sports_baseball,
      Color(0xFF3B82F6), 'best_ball', null),
  const GameEntry('Sliding Puzzle', 'Slide tiles into order', Icons.apps,
      Color(0xFF8B5CF6), 'best_slide', null),
  const GameEntry('Memory Match', 'Flip cards, find the pairs', Icons.style,
      Color(0xFFEF4444), 'best_memory', null),
  const GameEntry('Sudoku', 'The classic number puzzle', Icons.grid_3x3,
      Color(0xFF06B6D4), 'best_sudoku', null),
  const GameEntry('Flow Connect', 'Join the matching dots', Icons.timeline,
      Color(0xFFF97316), 'best_flow', null),
  const GameEntry('Minesweeper', 'Find every mine — carefully!', Icons.flag,
      Color(0xFF64748B), 'best_mines', null),
  const GameEntry('Tic Tac Toe', 'Beat the computer', Icons.close,
      Color(0xFF84CC16), 'best_ttt', null),
];

class HubPage extends StatefulWidget {
  const HubPage({super.key});
  @override
  State<HubPage> createState() => _HubPageState();
}

class _HubPageState extends State<HubPage> {
  Map<String, int> _bests = {};

  @override
  void initState() {
    super.initState();
    _loadBests();
  }

  Future<void> _loadBests() async {
    final prefs = await SharedPreferences.getInstance();
    final map = <String, int>{};
    for (final g in kGames) {
      map[g.bestKey] = prefs.getInt(g.bestKey) ?? 0;
    }
    if (mounted) setState(() => _bests = map);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF7C3AED), Color(0xFFDB2777)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Puzzle World',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.w800)),
                  SizedBox(height: 4),
                  Text('10 puzzle games in one app — pick your game!',
                      style: TextStyle(color: Colors.white70, fontSize: 14)),
                ],
              ),
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(14),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.12,
                ),
                itemCount: kGames.length,
                itemBuilder: (context, i) {
                  final g = kGames[i];
                  final playable = g.page != null;
                  final best = _bests[g.bestKey] ?? 0;
                  return InkWell(
                    borderRadius: BorderRadius.circular(18),
                    onTap: playable
                        ? () async {
                            await Navigator.of(context).push(
                              MaterialPageRoute(builder: (_) => g.page!()),
                            );
                            _loadBests();
                          }
                        : null,
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: g.color.withOpacity(playable ? 0.22 : 0.10),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                            color: g.color.withOpacity(playable ? 0.65 : 0.25),
                            width: 1.4),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(g.icon,
                              size: 34,
                              color: playable ? g.color : g.color.withOpacity(0.45)),
                          const Spacer(),
                          Text(g.name,
                              style: TextStyle(
                                  fontSize: 16.5,
                                  fontWeight: FontWeight.w700,
                                  color: playable ? Colors.white : Colors.white60)),
                          const SizedBox(height: 2),
                          Text(g.tagline,
                              style: const TextStyle(
                                  fontSize: 11.5, color: Colors.white54),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis),
                          const SizedBox(height: 6),
                          if (playable)
                            Text(best > 0 ? 'Best: $best' : 'Tap to play',
                                style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: g.color))
                          else
                            const Text('COMING SOON',
                                style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 1,
                                    color: Colors.white38)),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Shared bits
// ---------------------------------------------------------------------------
class HeartsBar extends StatelessWidget {
  final int hearts;
  final int maxHearts;
  const HeartsBar({super.key, required this.hearts, this.maxHearts = 3});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(
        maxHearts,
        (i) => Icon(
          i < hearts ? Icons.favorite : Icons.favorite_border,
          color: Colors.redAccent,
          size: 20,
        ),
      ),
    );
  }
}

Future<void> saveBest(String key, int score) async {
  final prefs = await SharedPreferences.getInstance();
  final old = prefs.getInt(key) ?? 0;
  if (score > old) await prefs.setInt(key, score);
}

// ---------------------------------------------------------------------------
// GAME 1 — Candy Match (match-3)
// Levels get harder: target rises, moves shrink, a 6th candy joins at L4.
// Fail a level and you lose a heart; an ad can give the heart back and let
// the run continue from the same board. A hint also costs one ad.
// ---------------------------------------------------------------------------
class CandyMatchPage extends StatefulWidget {
  const CandyMatchPage({super.key});
  @override
  State<CandyMatchPage> createState() => _CandyMatchPageState();
}

class _CandyMatchPageState extends State<CandyMatchPage> {
  static const int n = 8;
  static const List<Color> kCandyColors = [
    Color(0xFFEF4444), Color(0xFFF97316), Color(0xFFEAB308),
    Color(0xFF22C55E), Color(0xFF3B82F6), Color(0xFFA855F7),
  ];
  static const List<IconData> kCandyGlyphs = [
    Icons.circle, Icons.change_history, Icons.star,
    Icons.diamond, Icons.favorite, Icons.hexagon,
  ];

  final Random _rng = Random();
  late List<List<int>> b;
  int level = 1;
  int hearts = 3;
  int totalScore = 0;
  int levelScore = 0;
  int movesLeft = 0;
  int selR = -1, selC = -1;
  int hintR1 = -1, hintC1 = -1, hintR2 = -1, hintC2 = -1;
  bool busy = false;
  bool runOver = false;

  int get typeCount => level >= 4 ? 6 : 5;
  int get target => 400 + (level - 1) * 250;
  int get startMoves => max(20, 30 - (level - 1));

  @override
  void initState() {
    super.initState();
    _newLevel();
  }

  void _newLevel() {
    movesLeft = startMoves;
    levelScore = 0;
    selR = selC = -1;
    _genBoard();
  }

  void _genBoard() {
    do {
      b = List.generate(n, (_) => List.generate(n, (_) => _rng.nextInt(typeCount)));
      // remove any starting matches by re-rolling the third in a row/col
      for (int r = 0; r < n; r++) {
        for (int c = 0; c < n; c++) {
          while ((c >= 2 && b[r][c] == b[r][c - 1] && b[r][c] == b[r][c - 2]) ||
              (r >= 2 && b[r][c] == b[r - 1][c] && b[r][c] == b[r - 2][c])) {
            b[r][c] = _rng.nextInt(typeCount);
          }
        }
      }
    } while (_findPossibleMove() == null);
  }

  List<List<bool>> _matchGrid() {
    final m = List.generate(n, (_) => List.filled(n, false));
    for (int r = 0; r < n; r++) {
      int run = 1;
      for (int c = 1; c <= n; c++) {
        if (c < n && b[r][c] >= 0 && b[r][c] == b[r][c - 1]) {
          run++;
        } else {
          if (run >= 3) {
            for (int k = c - run; k < c; k++) m[r][k] = true;
          }
          run = 1;
        }
      }
    }
    for (int c = 0; c < n; c++) {
      int run = 1;
      for (int r = 1; r <= n; r++) {
        if (r < n && b[r][c] >= 0 && b[r][c] == b[r - 1][c]) {
          run++;
        } else {
          if (run >= 3) {
            for (int k = r - run; k < r; k++) m[k][c] = true;
          }
          run = 1;
        }
      }
    }
    return m;
  }

  bool _hasMatch() => _matchGrid().any((row) => row.any((x) => x));

  void _swap(int r1, int c1, int r2, int c2) {
    final t = b[r1][c1];
    b[r1][c1] = b[r2][c2];
    b[r2][c2] = t;
  }

  List<int>? _findPossibleMove() {
    for (int r = 0; r < n; r++) {
      for (int c = 0; c < n; c++) {
        for (final d in const [
          [0, 1],
          [1, 0]
        ]) {
          final r2 = r + d[0], c2 = c + d[1];
          if (r2 >= n || c2 >= n) continue;
          _swap(r, c, r2, c2);
          final ok = _hasMatch();
          _swap(r, c, r2, c2);
          if (ok) return [r, c, r2, c2];
        }
      }
    }
    return null;
  }

  Future<void> _onTap(int r, int c) async {
    if (busy || runOver) return;
    if (selR < 0) {
      setState(() {
        selR = r;
        selC = c;
      });
      return;
    }
    if (selR == r && selC == c) {
      setState(() {
        selR = selC = -1;
      });
      return;
    }
    final adjacent = (selR - r).abs() + (selC - c).abs() == 1;
    if (!adjacent) {
      setState(() {
        selR = r;
        selC = c;
      });
      return;
    }
    final r1 = selR, c1 = selC;
    setState(() {
      selR = selC = -1;
      hintR1 = hintC1 = hintR2 = hintC2 = -1;
      busy = true;
    });
    _swap(r1, c1, r, c);
    setState(() {});
    await Future.delayed(const Duration(milliseconds: 140));
    if (!_hasMatch()) {
      _swap(r1, c1, r, c);
      if (mounted) {
        setState(() => busy = false);
      }
      return;
    }
    movesLeft--;
    await _resolveBoard();
    if (!mounted) return;
    setState(() => busy = false);
    _afterMove();
  }

  Future<void> _resolveBoard() async {
    int chain = 1;
    while (true) {
      final m = _matchGrid();
      int count = 0;
      for (final row in m) {
        for (final x in row) {
          if (x) count++;
        }
      }
      if (count == 0) break;
      final gained = count * 10 * chain;
      setState(() {
        levelScore += gained;
        totalScore += gained;
        for (int r = 0; r < n; r++) {
          for (int c = 0; c < n; c++) {
            if (m[r][c]) b[r][c] = -1;
          }
        }
      });
      await Future.delayed(const Duration(milliseconds: 170));
      if (!mounted) return;
      setState(() {
        // gravity + refill
        for (int c = 0; c < n; c++) {
          final stack = <int>[];
          for (int r = n - 1; r >= 0; r--) {
            if (b[r][c] >= 0) stack.add(b[r][c]);
          }
          for (int r = n - 1; r >= 0; r--) {
            final idx = n - 1 - r;
            b[r][c] = idx < stack.length ? stack[idx] : _rng.nextInt(typeCount);
          }
        }
      });
      await Future.delayed(const Duration(milliseconds: 120));
      if (!mounted) return;
      chain++;
    }
    if (_findPossibleMove() == null) {
      // no moves left on the board: shuffle the candies (free, fair play)
      final flat = [for (final row in b) ...row];
      do {
        flat.shuffle(_rng);
        int i = 0;
        for (int r = 0; r < n; r++) {
          for (int c = 0; c < n; c++) {
            b[r][c] = flat[i++];
          }
        }
      } while (_hasMatch() || _findPossibleMove() == null);
      if (mounted) {
        setState(() {});
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No moves left — board shuffled!')),
        );
      }
    }
  }

  void _afterMove() {
    if (levelScore >= target) {
      final bonus = movesLeft * 20;
      totalScore += bonus;
      saveBest('best_candy', totalScore);
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          title: Text('Level $level cleared! 🎉'),
          content: Text(
              'Bonus for spare moves: +$bonus\nTotal score: $totalScore\n\nLevel ${level + 1} will be harder — higher target, fewer moves.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                setState(() {
                  level++;
                  _newLevel();
                });
              },
              child: const Text('Next level'),
            ),
          ],
        ),
      );
    } else if (movesLeft <= 0) {
      hearts--;
      if (hearts > 0) {
        _showFailDialog(canAffordHeart: true);
      } else {
        _showFailDialog(canAffordHeart: false);
      }
    }
  }

  void _showFailDialog({required bool canAffordHeart}) {
    saveBest('best_candy', totalScore);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Out of moves!'),
        content: Text(canAffordHeart
            ? 'You lost a heart — $hearts left.\nKeep this level going with +8 moves?'
            : 'No hearts left!\nWatch an ad to earn a heart and keep this run alive — or end the run.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _endRun();
            },
            child: const Text('End run'),
          ),
          if (canAffordHeart)
            TextButton(
              onPressed: () {
                Navigator.pop(ctx);
                setState(() => movesLeft += 8);
              },
              child: Text('Use a heart ($hearts left)'),
            ),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              final ok = await showRewardedAd(context);
              if (ok && mounted) {
                setState(() {
                  hearts++;
                  movesLeft += 8;
                });
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('+1 heart! Keep going!')),
                );
              } else if (mounted) {
                // ad not completed: if hearts remain, back to the choice
                if (hearts > 0) {
                  _showFailDialog(canAffordHeart: true);
                } else {
                  _showFailDialog(canAffordHeart: false);
                }
              }
            },
            child: const Text('Watch ad: +1 heart'),
          ),
        ],
      ),
    );
  }

  Future<void> _endRun() async {
    runOver = true;
    await saveBest('best_candy', totalScore);
    if (!mounted) return;
    await showAdBreak(context);
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Run over!'),
        content: Text('You reached level $level.\nFinal score: $totalScore'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Home'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                level = 1;
                hearts = 3;
                totalScore = 0;
                runOver = false;
                _newLevel();
              });
            },
            child: const Text('Play again'),
          ),
        ],
      ),
    );
  }

  Future<void> _useHint() async {
    if (busy || runOver) return;
    final ok = await showRewardedAd(context);
    if (!ok || !mounted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Watch the full ad to earn a hint.')),
        );
      }
      return;
    }
    final mv = _findPossibleMove();
    if (mv == null) return;
    setState(() {
      hintR1 = mv[0];
      hintC1 = mv[1];
      hintR2 = mv[2];
      hintC2 = mv[3];
    });
    await Future.delayed(const Duration(seconds: 3));
    if (mounted) {
      setState(() {
        hintR1 = hintC1 = hintR2 = hintC2 = -1;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final progress = (levelScore / target).clamp(0.0, 1.0);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Candy Match'),
        actions: [
          TextButton.icon(
            onPressed: _useHint,
            icon: const Icon(Icons.lightbulb, size: 18),
            label: const Text('Hint (Ad)'),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Level $level',
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w700)),
                  HeartsBar(hearts: hearts),
                  Text('Moves: $movesLeft',
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Row(
                children: [
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: progress,
                        minHeight: 12,
                        backgroundColor: Colors.white12,
                        color: const Color(0xFFEC4899),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text('$levelScore / $target',
                      style: const TextStyle(fontSize: 13, color: Colors.white70)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Total score: $totalScore',
                    style: const TextStyle(fontSize: 13, color: Colors.white54)),
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 1,
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: GridView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: n,
                        mainAxisSpacing: 4,
                        crossAxisSpacing: 4,
                      ),
                      itemCount: n * n,
                      itemBuilder: (context, i) {
                        final r = i ~/ n, c = i % n;
                        final v = b[r][c];
                        final selected = r == selR && c == selC;
                        final hinted = (r == hintR1 && c == hintC1) ||
                            (r == hintR2 && c == hintC2);
                        return GestureDetector(
                          onTap: () => _onTap(r, c),
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: v >= 0
                                  ? LinearGradient(
                                      colors: [
                                        kCandyColors[v].withOpacity(0.95),
                                        kCandyColors[v].withOpacity(0.6),
                                      ],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    )
                                  : null,
                              color: v < 0 ? Colors.white10 : null,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: hinted
                                    ? Colors.amber
                                    : selected
                                        ? Colors.white
                                        : Colors.transparent,
                                width: hinted || selected ? 3 : 1,
                              ),
                            ),
                            child: v >= 0
                                ? Icon(kCandyGlyphs[v],
                                    color: Colors.white, size: 22)
                                : null,
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: Text(
                'Tap a candy, then tap a neighbour to swap. Match 3 or more!',
                style: TextStyle(color: Colors.white38, fontSize: 12.5),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// GAME 2 — 2048
// Swipe to slide and merge. When the board locks up you lose a heart; an ad
// earns the heart back and revives the SAME board (all 2s and 4s cleared).
// A hint (one ad) points out the best swipe, worked out by trying them all.
// ---------------------------------------------------------------------------
class Game2048Page extends StatefulWidget {
  const Game2048Page({super.key});
  @override
  State<Game2048Page> createState() => _Game2048PageState();
}

enum Dir { left, right, up, down }

class _Game2048PageState extends State<Game2048Page> {
  static const int n = 4;
  final Random _rng = Random();
  late List<List<int>> b;
  int score = 0;
  int hearts = 3;
  bool runOver = false;
  bool wonOnce = false;
  bool busy = false;
  String hintText = '';

  @override
  void initState() {
    super.initState();
    _newGame();
  }

  void _newGame() {
    b = List.generate(n, (_) => List.filled(n, 0));
    score = 0;
    hearts = 3;
    runOver = false;
    wonOnce = false;
    hintText = '';
    _spawn();
    _spawn();
  }

  void _spawn() {
    final empty = <List<int>>[];
    for (int r = 0; r < n; r++) {
      for (int c = 0; c < n; c++) {
        if (b[r][c] == 0) empty.add([r, c]);
      }
    }
    if (empty.isEmpty) return;
    final cell = empty[_rng.nextInt(empty.length)];
    b[cell[0]][cell[1]] = _rng.nextDouble() < 0.9 ? 2 : 4;
  }

  // Merge one line of 4 towards index 0; returns [newLine, gained].
  List<dynamic> _mergeLine(List<int> line) {
    final vals = line.where((x) => x != 0).toList();
    final out = <int>[];
    int gained = 0;
    int i = 0;
    while (i < vals.length) {
      if (i + 1 < vals.length && vals[i] == vals[i + 1]) {
        final nv = vals[i] * 2;
        out.add(nv);
        gained += nv;
        i += 2;
      } else {
        out.add(vals[i]);
        i++;
      }
    }
    while (out.length < n) out.add(0);
    return [out, gained];
  }

  // Apply a move to board [bd]; returns [changed, gained].
  List<dynamic> _applyMove(List<List<int>> bd, Dir dir) {
    int gained = 0;
    bool changed = false;
    for (int i = 0; i < n; i++) {
      // extract the line in movement order
      final line = <int>[];
      for (int j = 0; j < n; j++) {
        switch (dir) {
          case Dir.left:
            line.add(bd[i][j]);
            break;
          case Dir.right:
            line.add(bd[i][n - 1 - j]);
            break;
          case Dir.up:
            line.add(bd[j][i]);
            break;
          case Dir.down:
            line.add(bd[n - 1 - j][i]);
            break;
        }
      }
      final res = _mergeLine(line);
      final merged = res[0] as List<int>;
      gained += res[1] as int;
      for (int j = 0; j < n; j++) {
        int r, c;
        switch (dir) {
          case Dir.left:
            r = i; c = j; break;
          case Dir.right:
            r = i; c = n - 1 - j; break;
          case Dir.up:
            r = j; c = i; break;
          case Dir.down:
            r = n - 1 - j; c = i; break;
        }
        if (bd[r][c] != merged[j]) changed = true;
        bd[r][c] = merged[j];
      }
    }
    return [changed, gained];
  }

  bool _isLocked(List<List<int>> bd) {
    for (int r = 0; r < n; r++) {
      for (int c = 0; c < n; c++) {
        if (bd[r][c] == 0) return false;
        if (c + 1 < n && bd[r][c] == bd[r][c + 1]) return false;
        if (r + 1 < n && bd[r][c] == bd[r + 1][c]) return false;
      }
    }
    return true;
  }

  Future<void> _move(Dir dir) async {
    if (busy || runOver) return;
    final copy = [for (final row in b) [...row]];
    final res = _applyMove(copy, dir);
    if (res[0] != true) return;
    setState(() {
      b = copy;
      score += res[1] as int;
      _spawn();
      hintText = '';
    });
    saveBest('best_2048', score);
    if (!wonOnce && b.any((row) => row.any((v) => v >= 2048))) {
      wonOnce = true;
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('You made 2048! 🏆'),
          content: const Text(
              'Amazing! Keep going for an even bigger score — how far can you get?'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Keep playing')),
          ],
        ),
      );
      return;
    }
    if (_isLocked(b)) {
      hearts--;
      await Future.delayed(const Duration(milliseconds: 250));
      if (mounted) _showStuckDialog();
    }
  }

  void _revive() {
    setState(() {
      for (int r = 0; r < n; r++) {
        for (int c = 0; c < n; c++) {
          if (b[r][c] == 2 || b[r][c] == 4) b[r][c] = 0;
        }
      }
      _spawn();
      _spawn();
    });
  }

  void _showStuckDialog() {
    saveBest('best_2048', score);
    final canAffordHeart = hearts > 0;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Board locked!'),
        content: Text(canAffordHeart
            ? 'No moves left — you lost a heart, $hearts remaining.\nRevive this board? The 2 and 4 tiles will be cleared and your score stays.'
            : 'No hearts left!\nWatch an ad to earn a heart and revive this board — or end the run.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _endRun();
            },
            child: const Text('End run'),
          ),
          if (canAffordHeart)
            TextButton(
              onPressed: () {
                Navigator.pop(ctx);
                _revive();
              },
              child: Text('Use a heart ($hearts left)'),
            ),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              final ok = await showRewardedAd(context);
              if (ok && mounted) {
                setState(() => hearts++);
                _revive();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('+1 heart — board revived!')),
                );
              } else if (mounted) {
                _showStuckDialog();
              }
            },
            child: const Text('Watch ad: +1 heart'),
          ),
        ],
      ),
    );
  }

  Future<void> _endRun() async {
    runOver = true;
    await saveBest('best_2048', score);
    if (!mounted) return;
    await showAdBreak(context);
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Run over!'),
        content: Text('Final score: $score'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Home'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(_newGame);
            },
            child: const Text('Play again'),
          ),
        ],
      ),
    );
  }

  Future<void> _useHint() async {
    if (busy || runOver) return;
    final ok = await showRewardedAd(context);
    if (!ok || !mounted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Watch the full ad to earn a hint.')),
        );
      }
      return;
    }
    Dir? bestDir;
    int bestScore = -1;
    for (final dir in Dir.values) {
      final copy = [for (final row in b) [...row]];
      final res = _applyMove(copy, dir);
      if (res[0] != true) continue;
      int empty = 0;
      for (final row in copy) {
        for (final v in row) {
          if (v == 0) empty++;
        }
      }
      final s = (res[1] as int) + empty * 12;
      if (s > bestScore) {
        bestScore = s;
        bestDir = dir;
      }
    }
    if (bestDir == null) return;
    const arrows = {
      Dir.left: '⬅ Swipe LEFT',
      Dir.right: 'Swipe RIGHT ➡',
      Dir.up: '⬆ Swipe UP',
      Dir.down: '⬇ Swipe DOWN',
    };
    setState(() => hintText = 'Hint: ${arrows[bestDir]}');
    await Future.delayed(const Duration(seconds: 3));
    if (mounted) setState(() => hintText = '');
  }

  Color _tileColor(int v) {
    switch (v) {
      case 2: return const Color(0xFFEEE4DA);
      case 4: return const Color(0xFFEDE0C8);
      case 8: return const Color(0xFFF2B179);
      case 16: return const Color(0xFFF59563);
      case 32: return const Color(0xFFF67C5F);
      case 64: return const Color(0xFFF65E3B);
      case 128: return const Color(0xFFEDCF72);
      case 256: return const Color(0xFFEDCC61);
      case 512: return const Color(0xFFEDC850);
      case 1024: return const Color(0xFFEDC53F);
      case 2048: return const Color(0xFFEDC22E);
      default: return const Color(0xFF3C3A32);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('2048'),
        actions: [
          TextButton.icon(
            onPressed: _useHint,
            icon: const Icon(Icons.lightbulb, size: 18),
            label: const Text('Hint (Ad)'),
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'New game',
            onPressed: () => setState(_newGame),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Score: $score',
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w700)),
                  HeartsBar(hearts: hearts),
                ],
              ),
            ),
            if (hintText.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(hintText,
                    style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: Colors.amber)),
              ),
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 1,
                  child: GestureDetector(
                    onHorizontalDragEnd: (d) {
                      final v = d.primaryVelocity ?? 0;
                      if (v.abs() < 60) return;
                      _move(v > 0 ? Dir.right : Dir.left);
                    },
                    onVerticalDragEnd: (d) {
                      final v = d.primaryVelocity ?? 0;
                      if (v.abs() < 60) return;
                      _move(v > 0 ? Dir.down : Dir.up);
                    },
                    child: Container(
                      margin: const EdgeInsets.all(14),
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFBBADA0),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: GridView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: n,
                          mainAxisSpacing: 8,
                          crossAxisSpacing: 8,
                        ),
                        itemCount: n * n,
                        itemBuilder: (context, i) {
                          final v = b[i ~/ n][i % n];
                          return Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: v == 0
                                  ? const Color(0xFFCDC1B4)
                                  : _tileColor(v),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: v == 0
                                ? null
                                : Text(
                                    '$v',
                                    style: TextStyle(
                                      fontSize: v >= 1000
                                          ? 21
                                          : v >= 100
                                              ? 26
                                              : 32,
                                      fontWeight: FontWeight.w800,
                                      color: v <= 4
                                          ? const Color(0xFF776E65)
                                          : Colors.white,
                                    ),
                                  ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: Text(
                'Swipe up, down, left or right. Same numbers merge into one!',
                style: TextStyle(color: Colors.white38, fontSize: 12.5),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// GAME 3 — Block Puzzle
// Drag blocks onto the 10x10 board; full rows or columns clear. When no
// piece fits you lose a heart; an ad earns it back and revives the run
// (bottom rows cleared, fresh pieces dealt, score kept).
// ---------------------------------------------------------------------------
class BlockPuzzlePage extends StatefulWidget {
  const BlockPuzzlePage({super.key});
  @override
  State<BlockPuzzlePage> createState() => _BlockPuzzlePageState();
}

class _Piece {
  final List<List<int>> cells; // [r, c] offsets, tight bounding box
  final int color;
  _Piece(this.cells, this.color);
  int get rows => cells.map((e) => e[0]).reduce(max) + 1;
  int get cols => cells.map((e) => e[1]).reduce(max) + 1;
}

const List<List<List<int>>> kShapes = [
  [[0, 0]],
  [[0, 0], [0, 1]],
  [[0, 0], [1, 0]],
  [[0, 0], [0, 1], [0, 2]],
  [[0, 0], [1, 0], [2, 0]],
  [[0, 0], [0, 1], [0, 2], [0, 3]],
  [[0, 0], [1, 0], [2, 0], [3, 0]],
  [[0, 0], [0, 1], [0, 2], [0, 3], [0, 4]],
  [[0, 0], [1, 0], [2, 0], [3, 0], [4, 0]],
  [[0, 0], [0, 1], [1, 0], [1, 1]],
  [[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2], [2, 0], [2, 1], [2, 2]],
  [[0, 0], [1, 0], [1, 1]],
  [[0, 0], [0, 1], [1, 0]],
  [[0, 0], [0, 1], [1, 1]],
  [[0, 1], [1, 0], [1, 1]],
  [[0, 0], [0, 1], [0, 2], [1, 1]],
  [[0, 1], [1, 0], [1, 1], [1, 2]],
  [[0, 0], [1, 0], [2, 0], [2, 1]],
  [[0, 0], [0, 1], [1, 1], [1, 2]],
  [[0, 1], [0, 2], [1, 0], [1, 1]],
];

const List<Color> kBlockColors = [
  Color(0xFFEF4444), Color(0xFFF97316), Color(0xFFEAB308), Color(0xFF22C55E),
  Color(0xFF06B6D4), Color(0xFF3B82F6), Color(0xFFA855F7), Color(0xFFEC4899),
];

class _BlockPuzzlePageState extends State<BlockPuzzlePage> {
  static const int n = 10;
  final Random _rng = Random();
  final GlobalKey _boardKey = GlobalKey();
  late List<List<int>> b;
  List<_Piece?> tray = [null, null, null];
  int score = 0;
  int hearts = 3;
  bool runOver = false;
  int hoverR = -1, hoverC = -1, hoverSlot = -1;
  bool hoverOk = false;

  @override
  void initState() {
    super.initState();
    _newGame();
  }

  void _newGame() {
    b = List.generate(n, (_) => List.filled(n, 0));
    score = 0;
    hearts = 3;
    runOver = false;
    _deal();
  }

  _Piece _randomPiece() {
    final shape = kShapes[_rng.nextInt(kShapes.length)];
    return _Piece(shape, 1 + _rng.nextInt(kBlockColors.length));
  }

  void _deal() {
    tray = [_randomPiece(), _randomPiece(), _randomPiece()];
  }

  bool _fits(_Piece p, int r0, int c0) {
    for (final cell in p.cells) {
      final r = r0 + cell[0], c = c0 + cell[1];
      if (r < 0 || r >= n || c < 0 || c >= n || b[r][c] != 0) return false;
    }
    return true;
  }

  bool _fitsAnywhere(_Piece p) {
    for (int r = 0; r < n; r++) {
      for (int c = 0; c < n; c++) {
        if (_fits(p, r, c)) return true;
      }
    }
    return false;
  }

  void _place(int slot, int r0, int c0) {
    final p = tray[slot]!;
    setState(() {
      for (final cell in p.cells) {
        b[r0 + cell[0]][c0 + cell[1]] = p.color;
      }
      score += p.cells.length;
      tray[slot] = null;
      hoverR = hoverC = hoverSlot = -1;
      // clear full rows and columns together
      final rows = <int>{};
      final cols = <int>{};
      for (int r = 0; r < n; r++) {
        if (b[r].every((v) => v != 0)) rows.add(r);
      }
      for (int c = 0; c < n; c++) {
        bool full = true;
        for (int r = 0; r < n; r++) {
          if (b[r][c] == 0) full = false;
        }
        if (full) cols.add(c);
      }
      final lines = rows.length + cols.length;
      if (lines > 0) {
        for (final r in rows) {
          for (int c = 0; c < n; c++) b[r][c] = 0;
        }
        for (final c in cols) {
          for (int r = 0; r < n; r++) b[r][c] = 0;
        }
        score += 10 * lines * lines;
      }
      if (tray.every((t) => t == null)) _deal();
    });
    saveBest('best_block', score);
    _checkStuck();
  }

  void _checkStuck() {
    if (runOver) return;
    final anyLeft = tray.where((t) => t != null).toList();
    if (anyLeft.isEmpty) return;
    if (anyLeft.any(_fitsAnywhere)) return;
    hearts--;
    Future.delayed(const Duration(milliseconds: 200), () {
      if (mounted) _showStuckDialog();
    });
  }

  void _revive() {
    setState(() {
      for (int r = n - 3; r < n; r++) {
        for (int c = 0; c < n; c++) {
          b[r][c] = 0;
        }
      }
      _deal();
    });
  }

  void _showStuckDialog() {
    saveBest('best_block', score);
    final canAffordHeart = hearts > 0;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('No piece fits!'),
        content: Text(canAffordHeart
            ? 'You lost a heart — $hearts left.\nRevive? The bottom 3 rows will be cleared, fresh pieces dealt, and your score stays.'
            : 'No hearts left!\nWatch an ad to earn a heart and revive this run — or end the run.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _endRun();
            },
            child: const Text('End run'),
          ),
          if (canAffordHeart)
            TextButton(
              onPressed: () {
                Navigator.pop(ctx);
                _revive();
              },
              child: Text('Use a heart ($hearts left)'),
            ),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              final ok = await showRewardedAd(context);
              if (ok && mounted) {
                setState(() => hearts++);
                _revive();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('+1 heart — run revived!')),
                );
              } else if (mounted) {
                _showStuckDialog();
              }
            },
            child: const Text('Watch ad: +1 heart'),
          ),
        ],
      ),
    );
  }

  Future<void> _endRun() async {
    runOver = true;
    await saveBest('best_block', score);
    if (!mounted) return;
    await showAdBreak(context);
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Run over!'),
        content: Text('Final score: $score'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Home'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(_newGame);
            },
            child: const Text('Play again'),
          ),
        ],
      ),
    );
  }

  Widget _pieceWidget(_Piece p, double cell) {
    return SizedBox(
      width: p.cols * cell,
      height: p.rows * cell,
      child: Stack(
        children: p.cells
            .map((e) => Positioned(
                  left: e[1] * cell,
                  top: e[0] * cell,
                  width: cell,
                  height: cell,
                  child: Container(
                    margin: const EdgeInsets.all(1),
                    decoration: BoxDecoration(
                      color: kBlockColors[p.color - 1],
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ))
            .toList(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final boardWidth = MediaQuery.of(context).size.width - 20;
    final cell = boardWidth / n;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Block Puzzle'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'New game',
            onPressed: () => setState(_newGame),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Score: $score',
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w700)),
                  HeartsBar(hearts: hearts),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: DragTarget<int>(
                onMove: (details) {
                  final slot = details.data;
                  final p = tray[slot];
                  if (p == null) return;
                  final box = _boardKey.currentContext?.findRenderObject()
                      as RenderBox?;
                  if (box == null) return;
                  final local = box.globalToLocal(details.offset);
                  final c0 = (local.dx / cell).round();
                  final r0 = (local.dy / cell).round();
                  setState(() {
                    hoverSlot = slot;
                    hoverR = r0;
                    hoverC = c0;
                    hoverOk = _fits(p, r0, c0);
                  });
                },
                onLeave: (_) => setState(() {
                  hoverR = hoverC = hoverSlot = -1;
                }),
                onAcceptWithDetails: (details) {
                  final slot = details.data;
                  final p = tray[slot];
                  if (p != null && hoverSlot == slot && hoverOk) {
                    _place(slot, hoverR, hoverC);
                  } else {
                    setState(() {
                      hoverR = hoverC = hoverSlot = -1;
                    });
                  }
                },
                builder: (context, candidate, rejected) {
                  // ghost footprint of the hovered piece
                  final ghost = <String, int>{};
                  if (hoverSlot >= 0 && tray[hoverSlot] != null) {
                    for (final e in tray[hoverSlot]!.cells) {
                      final r = hoverR + e[0], c = hoverC + e[1];
                      if (r >= 0 && r < n && c >= 0 && c < n) {
                        ghost['$r,$c'] = tray[hoverSlot]!.color;
                      }
                    }
                  }
                  return Container(
                    key: _boardKey,
                    width: boardWidth,
                    height: boardWidth,
                    padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      color: Colors.white10,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: GridView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: n,
                        mainAxisSpacing: 2,
                        crossAxisSpacing: 2,
                      ),
                      itemCount: n * n,
                      itemBuilder: (context, i) {
                        final r = i ~/ n, c = i % n;
                        final v = b[r][c];
                        final g = ghost['$r,$c'];
                        Color col;
                        if (v != 0) {
                          col = kBlockColors[v - 1];
                        } else if (g != null) {
                          col = hoverOk
                              ? kBlockColors[g - 1].withOpacity(0.55)
                              : Colors.red.withOpacity(0.45);
                        } else {
                          col = Colors.white12;
                        }
                        return Container(
                          decoration: BoxDecoration(
                            color: col,
                            borderRadius: BorderRadius.circular(3),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 6),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: List.generate(3, (slot) {
                  final p = tray[slot];
                  if (p == null) {
                    return const SizedBox(width: 92, height: 92);
                  }
                  return Draggable<int>(
                    data: slot,
                    feedback: Material(
                      color: Colors.transparent,
                      child: _pieceWidget(p, cell - 2),
                    ),
                    childWhenDragging: Opacity(
                      opacity: 0.25,
                      child: _pieceWidget(p, 17),
                    ),
                    child: Container(
                      width: 92,
                      height: 92,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: Colors.white10,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: _pieceWidget(p, 17),
                    ),
                  );
                }),
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: Text(
                'Drag blocks onto the board. Fill a full row or column to clear it!',
                style: TextStyle(color: Colors.white38, fontSize: 12.5),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
