import 'package:flutter/material.dart';
import 'services.dart';
import 'common.dart';
import 'game_block.dart';
import 'game_oneline.dart';
import 'game_tictactoe.dart';
import 'game_fruitmerge.dart';
import 'game_watersort.dart';
import 'game_onet.dart';
import 'game_mahjong.dart';
import 'game_sand.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Sfx.loadSettings();
  runApp(const GameApp());
}

class GameApp extends StatelessWidget {
  const GameApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Block Blast Games',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2D7FF9)),
      ),
      home: const HubPage(),
    );
  }
}

class _GameInfo {
  const _GameInfo(this.name, this.emoji, this.colors, this.builder, this.statKey,
      this.statIsLevel);
  final String name;
  final String emoji;
  final List<Color> colors;
  final WidgetBuilder builder;
  final String statKey;
  final bool statIsLevel;
}

final List<_GameInfo> _miniGames = [
  _GameInfo('One Line', '➰', [Color(0xFF37474F), Color(0xFF263238)],
      (_) => const OneLineGame(), 'oneline', true),
  _GameInfo('Tic Tac Toe', '✕○', [Color(0xFF5B8DC9), Color(0xFF3A6EA8)],
      (_) => const TicTacToeGame(), 'ttt', true),
  _GameInfo('Fruit Merge', '🍉', [Color(0xFFF2A65A), Color(0xFFE8833A)],
      (_) => const FruitMergeGame(), 'fruit', false),
  _GameInfo('Water Sort', '🧪', [Color(0xFF6C5CE7), Color(0xFF4834B8)],
      (_) => const WaterSortGame(), 'water', true),
  _GameInfo('Onet', '🍍', [Color(0xFF8D5A5A), Color(0xFF6B4242)],
      (_) => const OnetGame(), 'onet', true),
  _GameInfo('Mahjong', '🀄', [Color(0xFF1F7A6D), Color(0xFF14524A)],
      (_) => const MahjongGame(), 'mahjong', true),
  _GameInfo('Sand Crush', '🏖️', [Color(0xFF2D7FF9), Color(0xFF1B4FA8)],
      (_) => const SandCrushGame(), 'sand', true),
];

class HubPage extends StatefulWidget {
  const HubPage({super.key});
  @override
  State<HubPage> createState() => _HubPageState();
}

class _HubPageState extends State<HubPage> {
  final Map<String, int> _stats = {};
  int _blockBest = 0;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final map = <String, int>{};
    for (final g in _miniGames) {
      map[g.statKey] = g.statIsLevel
          ? await Prefs.level(g.statKey)
          : await Prefs.best(g.statKey);
    }
    final bb = await Prefs.best('block');
    if (mounted) {
      setState(() {
        _stats.addAll(map);
        _blockBest = bb;
      });
    }
  }

  Future<void> _open(WidgetBuilder builder) async {
    Sfx.play('click');
    Sfx.startBgm();
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: builder));
    _loadStats();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF3D6BE0), Color(0xFF27408B), Color(0xFF1B2A5E)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: IconButton(
                  icon: const Icon(Icons.settings,
                      color: Colors.white70, size: 28),
                  onPressed: () {
                    Sfx.play('click');
                    _hubSettings(context);
                  },
                ),
              ),
              // logo
              _logo(),
              const SizedBox(height: 4),
              const Text('ADVENTURE MASTER',
                  style: TextStyle(
                      color: Color(0xFF9FC6E8),
                      letterSpacing: 3,
                      fontWeight: FontWeight.w700,
                      fontSize: 13)),
              const SizedBox(height: 18),
              // flagship card
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                child: Material(
                  borderRadius: BorderRadius.circular(22),
                  elevation: 6,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(22),
                    onTap: () => _open((_) => const BlockBlastGame()),
                    child: Container(
                      height: 118,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(22),
                        gradient: const LinearGradient(
                          colors: [Color(0xFF7B2FF7), Color(0xFF2D7FF9)],
                        ),
                      ),
                      child: Row(
                        children: [
                          const SizedBox(width: 18),
                          PieceView(
                            cells: const [
                              [0, 0], [1, 0], [2, 0], [1, 1]
                            ],
                            color: 3,
                            cell: 21,
                          ),
                          const SizedBox(width: 8),
                          PieceView(
                            cells: const [
                              [0, 0], [0, 1], [1, 1]
                            ],
                            color: 1,
                            cell: 21,
                          ),
                          const Spacer(),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              const Text('Block Blast',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 27,
                                      fontWeight: FontWeight.w900)),
                              Text('👑 Best: $_blockBest',
                                  style: const TextStyle(
                                      color: Color(0xFFFFD93B),
                                      fontSize: 16,
                                      fontWeight: FontWeight.w800)),
                              const SizedBox(height: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 6),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF35C759),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: const Text('PLAY',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w900,
                                        fontSize: 15)),
                              ),
                            ],
                          ),
                          const SizedBox(width: 18),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              // mini games grid
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 14,
                    mainAxisSpacing: 14,
                    childAspectRatio: 1.45,
                  ),
                  itemCount: _miniGames.length,
                  itemBuilder: (_, i) {
                    final g = _miniGames[i];
                    final stat = _stats[g.statKey];
                    return Material(
                      borderRadius: BorderRadius.circular(20),
                      elevation: 4,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () => _open(g.builder),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: g.colors,
                            ),
                          ),
                          padding: const EdgeInsets.all(14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(g.emoji,
                                  style: const TextStyle(fontSize: 30)),
                              const Spacer(),
                              Text(g.name,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 19,
                                      fontWeight: FontWeight.w900)),
                              if (stat != null)
                                Text(
                                    g.statIsLevel
                                        ? 'Level $stat'
                                        : 'Best: $stat',
                                    style: const TextStyle(
                                        color: Colors.white70,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 13)),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _logo() {
    const letters = ['B', 'L', 'O', 'C', 'K'];
    const colors = [
      Color(0xFFF07D1A),
      Color(0xFF35A7E0),
      Color(0xFFEF3E36),
      Color(0xFFF5B921),
      Color(0xFFB565D8),
    ];
    return Column(
      children: [
        Stack(
          clipBehavior: Clip.none,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (int i = 0; i < letters.length; i++)
                  Text(letters[i],
                      style: TextStyle(
                        fontSize: 47,
                        fontWeight: FontWeight.w900,
                        color: colors[i],
                        shadows: const [
                          Shadow(
                              color: Colors.black38,
                              offset: Offset(0, 4),
                              blurRadius: 0)
                        ],
                      )),
              ],
            ),
            const Positioned(
              top: -19,
              left: 88,
              child: Text('👑', style: TextStyle(fontSize: 27)),
            ),
          ],
        ),
        const Text('BLAST',
            style: TextStyle(
              fontSize: 40,
              fontWeight: FontWeight.w900,
              letterSpacing: 6,
              color: Color(0xFF35C5E0),
              shadows: [
                Shadow(color: Colors.black38, offset: Offset(0, 4), blurRadius: 0)
              ],
            )),
      ],
    );
  }
}

void _hubSettings(BuildContext context) {
  showDialog(
    context: context,
    builder: (_) => StatefulBuilder(builder: (context, setD) {
      return AlertDialog(
        backgroundColor: const Color(0xFF2B3A8F),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('Settings',
            textAlign: TextAlign.center,
            style:
                TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SwitchListTile(
              title:
                  const Text('Sound', style: TextStyle(color: Colors.white)),
              value: Sfx.soundOn,
              onChanged: (v) {
                Sfx.soundOn = v;
                Prefs.setBool('set_sound', v);
                setD(() {});
              },
            ),
            SwitchListTile(
              title:
                  const Text('Music', style: TextStyle(color: Colors.white)),
              value: Sfx.bgmOn,
              onChanged: (v) {
                Sfx.bgmOn = v;
                Prefs.setBool('set_bgm', v);
                Sfx.applyBgm();
                setD(() {});
              },
            ),
            SwitchListTile(
              title: const Text('Vibration',
                  style: TextStyle(color: Colors.white)),
              value: Sfx.vibeOn,
              onChanged: (v) {
                Sfx.vibeOn = v;
                Prefs.setBool('set_vibe', v);
                setD(() {});
              },
            ),
          ],
        ),
      );
    }),
  );
}
