import 'package:flutter/material.dart';
import 'services.dart';

// ---------------------------------------------------------------------------
// Block colors: glossy jewel palette (Block Blast style, our own shades)
// index 0 unused; 1..8 are colors
// ---------------------------------------------------------------------------
const List<Color> kBlockBase = [
  Colors.transparent,
  Color(0xFFEF3E36), // red
  Color(0xFFF07D1A), // orange
  Color(0xFFF5B921), // yellow
  Color(0xFF35C759), // green
  Color(0xFF17B6CF), // cyan
  Color(0xFF2D7FF9), // blue
  Color(0xFF8B46C7), // purple
  Color(0xFFF0568B), // pink
];

Color lighten(Color c, [double f = 0.35]) =>
    Color.lerp(c, Colors.white, f) ?? c;
Color darken(Color c, [double f = 0.30]) =>
    Color.lerp(c, Colors.black, f) ?? c;

/// One glossy jewel block cell.
class GlossyCell extends StatelessWidget {
  const GlossyCell({super.key, required this.color, required this.size, this.ghost = false});
  final int color;
  final double size;
  final bool ghost;

  @override
  Widget build(BuildContext context) {
    final base = kBlockBase[color];
    final r = size * 0.18;
    Widget inner = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(r),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [lighten(base, 0.45), base, darken(base, 0.18)],
          stops: const [0.0, 0.55, 1.0],
        ),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.35),
              blurRadius: size * 0.06,
              offset: Offset(0, size * 0.05)),
        ],
      ),
      child: Stack(
        children: [
          // top gloss highlight
          Positioned(
            left: size * 0.10,
            top: size * 0.07,
            child: Container(
              width: size * 0.80,
              height: size * 0.36,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(r),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.white.withOpacity(0.50),
                    Colors.white.withOpacity(0.05)
                  ],
                ),
              ),
            ),
          ),
          // bottom bevel shade
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              height: size * 0.16,
              decoration: BoxDecoration(
                borderRadius:
                    BorderRadius.vertical(bottom: Radius.circular(r)),
                color: Colors.black.withOpacity(0.18),
              ),
            ),
          ),
        ],
      ),
    );
    if (ghost) return Opacity(opacity: 0.45, child: inner);
    return inner;
  }
}

/// A whole piece (shape) rendered at a given cell size.
class PieceView extends StatelessWidget {
  const PieceView(
      {super.key,
      required this.cells,
      required this.color,
      required this.cell,
      this.ghost = false});
  final List<List<int>> cells; // [ [x,y], ... ]
  final int color;
  final double cell;
  final bool ghost;

  @override
  Widget build(BuildContext context) {
    int maxX = 0, maxY = 0;
    for (final c in cells) {
      if (c[0] > maxX) maxX = c[0];
      if (c[1] > maxY) maxY = c[1];
    }
    return SizedBox(
      width: (maxX + 1) * cell,
      height: (maxY + 1) * cell,
      child: Stack(
        children: [
          for (final c in cells)
            Positioned(
              left: c[0] * cell + cell * 0.04,
              top: c[1] * cell + cell * 0.04,
              child: GlossyCell(
                  color: color, size: cell * 0.92, ghost: ghost),
            ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Standard game header: back, title, right-side widget; hint button helper
// ---------------------------------------------------------------------------
class GameHeader extends StatelessWidget {
  const GameHeader(
      {super.key,
      required this.title,
      this.trailing,
      this.onBack});
  final String title;
  final Widget? trailing;
  final VoidCallback? onBack;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 10, 8, 4),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_new,
                color: Colors.white, size: 22),
            onPressed: onBack ?? () => Navigator.of(context).pop(),
          ),
          Expanded(
            child: Text(title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 21,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.4)),
          ),
          SizedBox(width: 48, child: trailing ?? const SizedBox.shrink()),
        ],
      ),
    );
  }
}

/// Hint button: bulb with badge showing free hints left (or a play icon = ad).
class HintButton extends StatefulWidget {
  const HintButton({super.key, required this.onHint});
  final Future<void> Function() onHint;
  @override
  State<HintButton> createState() => _HintButtonState();
}

class _HintButtonState extends State<HintButton> {
  int _free = 0;
  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final f = await HintBank.freeLeft();
    if (mounted) setState(() => _free = f);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Material(
          color: const Color(0xFFF5B921),
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () async {
              Sfx.play('click');
              await widget.onHint();
              _refresh();
            },
            child: const Padding(
              padding: EdgeInsets.all(10),
              child: Icon(Icons.lightbulb, color: Colors.white, size: 26),
            ),
          ),
        ),
        Positioned(
          right: -6,
          top: -6,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: _free > 0 ? const Color(0xFF35C759) : const Color(0xFFEF3E36),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white, width: 1.5),
            ),
            child: Text(_free > 0 ? '$_free FREE' : 'AD',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.w900)),
          ),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Big praise word that pops and fades ("Good!", "Amazing!" ...)
// ---------------------------------------------------------------------------
class PraiseWord extends StatelessWidget {
  const PraiseWord({super.key, required this.word, required this.showKey});
  final String word;
  final int showKey;

  @override
  Widget build(BuildContext context) {
    if (word.isEmpty) return const SizedBox.shrink();
    return IgnorePointer(
      child: Center(
        child: TweenAnimationBuilder<double>(
          key: ValueKey(showKey),
          tween: Tween(begin: 0, end: 1),
          duration: const Duration(milliseconds: 750),
          builder: (context, t, _) {
            final scale = t < 0.3
                ? (t / 0.3) * 1.15
                : 1.15 - (t - 0.3) * 0.21; // pop then settle ~1.0
            final opacity = t > 0.7 ? 1 - (t - 0.7) / 0.3 : 1.0;
            return Opacity(
              opacity: opacity.clamp(0, 1),
              child: Transform.scale(
                scale: scale,
                child: Text(
                  word,
                  style: TextStyle(
                    fontSize: 52,
                    fontWeight: FontWeight.w900,
                    fontStyle: FontStyle.italic,
                    color: const Color(0xFFFFD93B),
                    shadows: const [
                      Shadow(
                          color: Color(0xFFB3540E),
                          offset: Offset(0, 4),
                          blurRadius: 0),
                      Shadow(color: Colors.black45, blurRadius: 12),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

/// Level complete dialog with Next button.
Future<void> showLevelComplete(BuildContext context,
    {required String title,
    required String message,
    required VoidCallback onNext,
    VoidCallback? onReplay}) {
  Sfx.play('win');
  Sfx.vibe(true);
  return showDialog(
    context: context,
    barrierDismissible: false,
    builder: (_) => AlertDialog(
      backgroundColor: const Color(0xFF2B3A8F),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      title: Text(title,
          textAlign: TextAlign.center,
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.w900, fontSize: 24)),
      content: Text(message,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white70, fontSize: 16)),
      actionsAlignment: MainAxisAlignment.center,
      actions: [
        if (onReplay != null)
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              onReplay();
            },
            child:
                const Text('Replay', style: TextStyle(color: Colors.white70)),
          ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF35C759),
            padding: const EdgeInsets.symmetric(horizontal: 34, vertical: 12),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          onPressed: () {
            Navigator.of(context).pop();
            onNext();
          },
          child: const Text('Next Level',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 17,
                  fontWeight: FontWeight.w800)),
        ),
      ],
    ),
  );
}
