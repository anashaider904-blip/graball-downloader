import 'dart:math';
import 'package:flutter/material.dart';
import 'services.dart';
import 'common.dart';

// ===========================================================================
// TIC TAC TOE vs robot. Bot gets smarter as your level rises:
// L1-2 random, L3-4 blocks, L5-6 near-perfect, L7+ perfect minimax.
// ===========================================================================

class TicTacToeGame extends StatefulWidget {
  const TicTacToeGame({super.key});
  @override
  State<TicTacToeGame> createState() => _TicTacToeGameState();
}

class _TicTacToeGameState extends State<TicTacToeGame> {
  final _rnd = Random();
  List<int> _b = List.filled(9, 0); // 1 = you (X), 2 = bot (O)
  int _you = 0, _bot = 0;
  int _level = 1;
  bool _roundOver = false;
  List<int> _winLine = [];
  int? _hintCell;
  bool _playerStarts = true;

  static const _lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    _level = await Prefs.level('ttt');
    if (!_playerStarts) _botMove();
  }

  int _winner(List<int> b) {
    for (final l in _lines) {
      if (b[l[0]] != 0 && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]]) {
        return b[l[0]];
      }
    }
    return 0;
  }

  List<int>? _winCells(List<int> b) {
    for (final l in _lines) {
      if (b[l[0]] != 0 && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]]) return l;
    }
    return null;
  }

  int _minimax(List<int> b, bool isMax) {
    final w = _winner(b);
    if (w == 2) return 10;
    if (w == 1) return -10;
    if (b.every((v) => v != 0)) return 0;
    int best = isMax ? -100 : 100;
    for (int i = 0; i < 9; i++) {
      if (b[i] != 0) continue;
      b[i] = isMax ? 2 : 1;
      final s = _minimax(b, !isMax);
      b[i] = 0;
      best = isMax ? max(best, s) : min(best, s);
    }
    return best;
  }

  int _bestMove(List<int> b, int who) {
    int bestScore = who == 2 ? -100 : 100;
    int move = -1;
    for (int i = 0; i < 9; i++) {
      if (b[i] != 0) continue;
      b[i] = who;
      final s = _minimax(b, who != 2);
      b[i] = 0;
      if (who == 2 ? s > bestScore : s < bestScore) {
        bestScore = s;
        move = i;
      }
    }
    return move;
  }

  void _botMove() {
    if (_roundOver) return;
    final empty = [for (int i = 0; i < 9; i++) if (_b[i] == 0) i];
    if (empty.isEmpty) return;
    int pick;
    if (_level <= 2) {
      pick = empty[_rnd.nextInt(empty.length)];
    } else if (_level <= 4) {
      // win if possible, block if needed, else random
      pick = _tactical(empty, true) ?? _tactical(empty, false) ??
          empty[_rnd.nextInt(empty.length)];
    } else if (_level <= 6) {
      pick = _rnd.nextDouble() < 0.25
          ? empty[_rnd.nextInt(empty.length)]
          : _bestMove(List<int>.from(_b), 2);
    } else {
      pick = _bestMove(List<int>.from(_b), 2);
    }
    setState(() => _b[pick] = 2);
    Sfx.play('place');
    _checkEnd();
  }

  int? _tactical(List<int> empty, bool forWin) {
    final who = forWin ? 2 : 1;
    for (final i in empty) {
      final copy = List<int>.from(_b);
      copy[i] = who;
      if (_winner(copy) == who) return i;
    }
    return null;
  }

  void _tap(int i) {
    if (_roundOver || _b[i] != 0) return;
    setState(() {
      _b[i] = 1;
      _hintCell = null;
    });
    Sfx.play('pop');
    Sfx.vibe();
    if (_checkEnd()) return;
    Future.delayed(const Duration(milliseconds: 450), () {
      if (mounted) _botMove();
    });
  }

  bool _checkEnd() {
    final w = _winner(_b);
    if (w != 0 || _b.every((v) => v != 0)) {
      setState(() {
        _roundOver = true;
        _winLine = _winCells(_b) ?? [];
        if (w == 1) _you++;
        if (w == 2) _bot++;
      });
      if (w == 1) {
        Sfx.play('win');
        _level++;
        Prefs.saveLevel('ttt', _level);
      } else if (w == 2) {
        Sfx.play('lose');
      } else {
        Sfx.play('blip');
      }
      return true;
    }
    return false;
  }

  void _nextRound() {
    setState(() {
      _b = List.filled(9, 0);
      _roundOver = false;
      _winLine = [];
      _hintCell = null;
      _playerStarts = !_playerStarts;
    });
    if (!_playerStarts) {
      Future.delayed(const Duration(milliseconds: 400), () {
        if (mounted) _botMove();
      });
    }
  }

  Future<void> _hint() async {
    final ok = await HintBank.useHint(context);
    if (!ok || !mounted || _roundOver) return;
    final m = _bestMove(List<int>.from(_b), 1);
    if (m >= 0) {
      setState(() => _hintCell = m);
      Sfx.play('blip');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF9FC6E8),
      body: SafeArea(
        child: Column(
          children: [
            GameHeader(title: 'Tic Tac Toe', trailing: HintButton(onHint: _hint)),
            // score pill: You vs Bot
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 46),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                color: const Color(0xFF7FB2DD),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 9),
                      decoration: const BoxDecoration(
                        color: Color(0xFFEF5B4D),
                        borderRadius:
                            BorderRadius.horizontal(left: Radius.circular(16)),
                      ),
                      child: Text('🧑  $_you',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w900)),
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Text('VS',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 19,
                            fontWeight: FontWeight.w900)),
                  ),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 9),
                      decoration: const BoxDecoration(
                        color: Color(0xFF5B8DC9),
                        borderRadius: BorderRadius.horizontal(
                            right: Radius.circular(16)),
                      ),
                      child: Text('$_bot  🤖',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w900)),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Text('Robot level $_level — it gets smarter!',
                style: const TextStyle(
                    color: Color(0xFF33506E), fontWeight: FontWeight.w700)),
            const SizedBox(height: 16),
            // board
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 26),
              child: AspectRatio(
                aspectRatio: 1,
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF27406E),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  padding: const EdgeInsets.all(10),
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                    ),
                    itemCount: 9,
                    itemBuilder: (_, i) {
                      final v = _b[i];
                      final inWin = _winLine.contains(i);
                      return GestureDetector(
                        onTap: () => _tap(i),
                        child: Container(
                          decoration: BoxDecoration(
                            color: inWin
                                ? const Color(0xFF3E6B35)
                                : const Color(0xFF1B2A4A),
                            borderRadius: BorderRadius.circular(14),
                            border: i == _hintCell
                                ? Border.all(color: Colors.white, width: 3)
                                : null,
                          ),
                          child: Center(
                            child: v == 0
                                ? const SizedBox.shrink()
                                : Text(v == 1 ? '✕' : '○',
                                    style: TextStyle(
                                        fontSize: 54,
                                        fontWeight: FontWeight.w900,
                                        color: v == 1
                                            ? const Color(0xFFEF5B4D)
                                            : const Color(0xFF35A7E0))),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            const SizedBox(height: 18),
            if (_roundOver)
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF35C759),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 34, vertical: 13),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: () {
                  Sfx.play('click');
                  _nextRound();
                },
                child: Text(
                    _winner(_b) == 1
                        ? 'You Win! Next Round'
                        : _winner(_b) == 2
                            ? 'Robot Wins — Try Again'
                            : 'Draw — Next Round',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w800)),
              ),
            const Spacer(),
            const Padding(
              padding: EdgeInsets.only(bottom: 14),
              child: Text('✦ Tic Tac Toe ✦',
                  style: TextStyle(color: Color(0xFF33506E))),
            ),
          ],
        ),
      ),
    );
  }
}
